package org.example.supported_attendance;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SupportedAttendanceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SupportedAttendanceApplication.class, args);
	}

}
