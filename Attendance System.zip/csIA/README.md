# Supported Attendance and Bonus System

An IB Computer Science project built with Java 17, Spring Boot, Thymeleaf, JDBC, and SQLite. The application manages simulated worker records, RFID-style attendance, configurable bonus rules, monthly calculations, and management visualisations.

The interface opens in English by default. Use the `English | 中文` control on any page to switch language; the selection is stored in the browser for one year. The project uses one codebase and one database for both languages.

## Requirements

- Eclipse Temurin JDK 17 (or another compatible JDK 17 distribution)
- A modern web browser
- No separate Maven or database installation is required

## Run on macOS

Open Terminal in the project folder and run each command on a separate line:

```bash
cd /path/to/csIA
chmod +x mvnw
./mvnw spring-boot:run
```

For example, if the folder is on the Desktop:

```bash
cd ~/Desktop/csIA
chmod +x mvnw
./mvnw spring-boot:run
```

If macOS blocks the downloaded script, run `xattr -d com.apple.quarantine mvnw` once and try again. The Maven wrapper requires `.mvn/wrapper/maven-wrapper.properties`; keep the hidden `.mvn` folder when copying the project.

## Run on Windows

Open Command Prompt in the project folder and run:

```cmd
mvnw.cmd spring-boot:run
```

In PowerShell, use:

```powershell
.\mvnw.cmd spring-boot:run
```

Do not copy the `PS ...>` prompt or a leading `>` character. The terminal remains occupied and displays logs while the server is running. Press `Ctrl+C` to stop it.

## Open the application

- Main entry: <http://localhost:8080/>
- Administrator login: <http://localhost:8080/login>
- Attendance terminal: <http://localhost:8080/attendance>
- System status: <http://localhost:8080/health>

Initial demonstration account:

```text
username: admin
password: 123456
```

The initial credentials are configured in `src/main/resources/application.properties`. They create an administrator only when that username is absent. The database stores a BCrypt password hash, not the plain password, and later restarts do not overwrite an existing account.

## Data and language design

- SQLite database: `data/attendance.db`
- Database table and column names are English.
- Persisted status values are language-neutral English codes such as `OPEN`, `COMPLETED`, `QUALIFIED`, and `NOT_QUALIFIED`.
- English interface text: `src/main/resources/messages.properties`
- Chinese interface text: `src/main/resources/messages_zh_CN.properties`
- All identity and attendance demonstration records are synthetic school-project data.

## Verification

Run all automated tests:

```bash
./mvnw test
```

On Windows Command Prompt, use `mvnw.cmd test`. The tests cover authentication, security routes, database schema, worker management, attendance, bonus thresholds, monthly calculation, page rendering, and English/Chinese language switching.
