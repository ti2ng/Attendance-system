package org.example.supported_attendance;

import org.example.supported_attendance.config.AdminAccountInitializer;
import org.example.supported_attendance.repository.StaffAccountRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.crypto.password.PasswordEncoder;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
class DatabaseAdminAuthenticationTests {

    @Autowired
    private StaffAccountRepository staffAccountRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private AdminAccountInitializer adminAccountInitializer;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @BeforeEach
    void restoreInitialAdministrator() {
        jdbcTemplate.update("DELETE FROM staff_account");
        staffAccountRepository.createIfMissing("admin", passwordEncoder.encode("test-password"));
    }

    @Test
    void initialAdministratorUsesBcryptHashInsteadOfPlainText() {
        var account = staffAccountRepository.findByUsername("admin").orElseThrow();

        assertThat(account.passwordHash()).startsWith("$2");
        assertThat(account.passwordHash()).isNotEqualTo("test-password");
        assertThat(passwordEncoder.matches("test-password", account.passwordHash())).isTrue();
        assertThat(account.active()).isTrue();
    }

    @Test
    void restartDoesNotOverwriteExistingPasswordOrDisabledState() throws Exception {
        String replacementHash = passwordEncoder.encode("changed-password");
        jdbcTemplate.update(
                "UPDATE staff_account SET password_hash = ?, active = 0 WHERE username = ?",
                replacementHash,
                "admin");

        adminAccountInitializer.run(null);

        var account = staffAccountRepository.findByUsername("admin").orElseThrow();
        assertThat(account.passwordHash()).isEqualTo(replacementHash);
        assertThat(account.active()).isFalse();
    }
}
