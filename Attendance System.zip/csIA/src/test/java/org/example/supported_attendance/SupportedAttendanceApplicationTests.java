package org.example.supported_attendance;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SupportedAttendanceApplicationTests {

	@Test
	void contextLoads() {
	}

}
