package org.example.supported_attendance;

import jakarta.servlet.http.Cookie;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import static org.hamcrest.Matchers.containsString;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
class InternationalizationTests {
    private static final String LANGUAGE_COOKIE = "supported-attendance-language";

    @Autowired MockMvc mockMvc;

    @Test
    void EnglishIsTheDefaultLanguage() throws Exception {
        mockMvc.perform(get("/login"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("Administrator Login")))
                .andExpect(content().string(containsString("Username")));
    }

    @Test
    void ChineseSelectionIsStoredAndUsedOnTheNextPage() throws Exception {
        MvcResult selection = mockMvc.perform(get("/login").param("lang", "zh_CN"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("管理员登录")))
                .andReturn();

        Cookie cookie = selection.getResponse().getCookie(LANGUAGE_COOKIE);
        org.assertj.core.api.Assertions.assertThat(cookie).isNotNull();
        mockMvc.perform(get("/health").cookie(cookie))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("系统运行正常")));
    }

    @Test
    @WithMockUser(username = "admin", roles = "ADMIN")
    void MainAdministratorPagesRenderInEnglish() throws Exception {
        String[] pages = {
                "/admin/dashboard",
                "/admin/workers",
                "/admin/workers/new",
                "/admin/attendance",
                "/admin/bonus-thresholds",
                "/admin/bonuses?month=2026-09",
                "/admin/analytics?month=2026-09"
        };
        for (String page : pages) {
            mockMvc.perform(get(page)).andExpect(status().isOk());
        }
    }
}
