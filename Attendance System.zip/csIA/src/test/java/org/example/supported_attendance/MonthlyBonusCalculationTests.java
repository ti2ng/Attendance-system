package org.example.supported_attendance;

import java.math.BigDecimal;

import org.example.supported_attendance.repository.BonusThresholdSettingsRepository;
import org.example.supported_attendance.repository.IdentityTokenRepository;
import org.example.supported_attendance.service.MonthlyBonusService;
import org.example.supported_attendance.service.WorkerService;
import org.example.supported_attendance.web.WorkerForm;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

@SpringBootTest
@AutoConfigureMockMvc
class MonthlyBonusCalculationTests {
    @Autowired JdbcTemplate jdbcTemplate;
    @Autowired WorkerService workerService;
    @Autowired IdentityTokenRepository tokenRepository;
    @Autowired BonusThresholdSettingsRepository thresholdRepository;
    @Autowired MonthlyBonusService bonusService;
    @Autowired MockMvc mockMvc;

    private long workerId;
    private long tokenId;

    @BeforeEach
    void setup() {
        jdbcTemplate.update("DELETE FROM monthly_bonus_daily_detail");
        jdbcTemplate.update("DELETE FROM monthly_bonus_result");
        jdbcTemplate.update("DELETE FROM attendance_session");
        jdbcTemplate.update("DELETE FROM identity_token");
        jdbcTemplate.update("DELETE FROM supported_worker");
        thresholdRepository.update(240, 2, new BigDecimal("50.00"), new BigDecimal("80.00"));
        workerId = workerService.create(form());
        tokenId = tokenRepository.create(workerId, "BONUS-TEST-CARD");
    }

    @Test
    void aggregatesDailySessionsAppliesQualificationAndMonthlyCap() {
        completed("2026-10-01T00:00:00Z", "2026-10-01T02:00:00Z");
        completed("2026-10-01T05:00:00Z", "2026-10-01T07:00:00Z");
        completed("2026-10-02T00:00:00Z", "2026-10-02T04:00:00Z");
        completed("2026-10-03T00:00:00Z", "2026-10-03T01:00:00Z");
        open("2026-10-04T00:00:00Z");

        bonusService.calculate("2026-10");
        var result = bonusService.findByMonth("2026-10").get(0);

        assertThat(result.totalCompletedMinutes()).isEqualTo(540);
        assertThat(result.validDays()).isEqualTo(2);
        assertThat(result.rawBonus()).isEqualByComparingTo("100.00");
        assertThat(result.finalBonus()).isEqualByComparingTo("80.00");
        assertThat(result.qualified()).isTrue();
        assertThat(bonusService.findDetails(result.resultId())).hasSize(3);
    }

    @Test
    void savedResultKeepsThresholdSnapshotAfterSettingsChange() {
        completed("2026-10-01T00:00:00Z", "2026-10-01T04:00:00Z");
        bonusService.calculate("2026-10");
        thresholdRepository.update(300, 20, new BigDecimal("99"), new BigDecimal("999"));

        var saved = bonusService.findByMonth("2026-10").get(0);
        assertThat(saved.dailyWorkMinutesThreshold()).isEqualTo(240);
        assertThat(saved.dailyBonusThreshold()).isEqualByComparingTo("50.00");
    }

    @Test
    void bonusPagesRequireAdministrator() throws Exception {
        mockMvc.perform(get("/admin/bonuses")).andExpect(status().is3xxRedirection());
    }

    @Test
    @WithMockUser(username = "admin", roles = "ADMIN")
    void administratorCanCalculateAndViewBonusPage() throws Exception {
        mockMvc.perform(post("/admin/bonuses/calculate").with(csrf()).param("month", "2026-10"))
                .andExpect(status().is3xxRedirection());
        mockMvc.perform(get("/admin/bonuses").param("month", "2026-10")).andExpect(status().isOk());
    }

    @Test
    @WithMockUser(username = "admin", roles = "ADMIN")
    void administratorCanOpenAnalyticsPage() throws Exception {
        mockMvc.perform(get("/admin/analytics").param("month", "2026-10"))
                .andExpect(status().isOk())
                .andExpect(view().name("admin/analytics"))
                .andExpect(model().attributeExists("results", "dailyAttendance", "threshold"));
    }

    private void completed(String in, String out) {
        jdbcTemplate.update("INSERT INTO attendance_session(worker_id,token_id,check_in_time,check_out_time,status,updated_at) "
                + "VALUES (?,?,?,?,'COMPLETED',?)", workerId, tokenId, in, out, out);
    }

    private void open(String in) {
        jdbcTemplate.update("INSERT INTO attendance_session(worker_id,token_id,check_in_time,status,updated_at) "
                + "VALUES (?,?,?,'OPEN',?)", workerId, tokenId, in, in);
    }

    private WorkerForm form() {
        WorkerForm form = new WorkerForm();
        form.setWorkerNumber("BONUS-WORKER-1");
        form.setFullName("Bonus Worker");
        form.setIdDocumentType("PROGRAM_ID");
        form.setIdDocumentNumber("BONUS-ID-1");
        return form;
    }
}
