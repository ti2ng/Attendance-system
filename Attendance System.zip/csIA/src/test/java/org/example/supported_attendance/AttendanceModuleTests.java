package org.example.supported_attendance;

import org.example.supported_attendance.repository.IdentityTokenRepository;
import org.example.supported_attendance.service.AttendanceResult;
import org.example.supported_attendance.service.AttendanceService;
import org.example.supported_attendance.service.WorkerService;
import org.example.supported_attendance.web.WorkerForm;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.redirectedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
class AttendanceModuleTests {
    @Autowired AttendanceService attendanceService;
    @Autowired WorkerService workerService;
    @Autowired IdentityTokenRepository tokenRepository;
    @Autowired JdbcTemplate jdbcTemplate;
    @Autowired MockMvc mockMvc;

    @BeforeEach
    void clearData() {
        jdbcTemplate.update("DELETE FROM monthly_bonus_daily_detail");
        jdbcTemplate.update("DELETE FROM monthly_bonus_result");
        jdbcTemplate.update("DELETE FROM attendance_session");
        jdbcTemplate.update("DELETE FROM identity_token");
        jdbcTemplate.update("DELETE FROM supported_worker");
        jdbcTemplate.update("UPDATE attendance_settings SET duplicate_scan_seconds=30, minimum_checkout_minutes=1 WHERE settings_id=1");
    }

    @Test
    void validCardChecksInAndThenChecksOut() {
        long workerId = createWorker("TEST-WORKER-1", "Worker Test 1", "TEST-ID-1");
        tokenRepository.create(workerId, "TEST-CARD-1");

        AttendanceResult checkIn = attendanceService.scan(" test-card-1 ");
        ageOpenSession();
        AttendanceResult checkOut = attendanceService.scan("TEST-CARD-1");

        assertThat(checkIn.title()).isEqualTo("签到成功");
        assertThat(checkOut.title()).isEqualTo("签退成功");
        assertThat(jdbcTemplate.queryForObject("SELECT status FROM attendance_session", String.class))
                .isEqualTo("COMPLETED");

        jdbcTemplate.update("UPDATE attendance_session SET updated_at='2020-01-01T00:00:00Z'");
        AttendanceResult nextCheckIn = attendanceService.scan("TEST-CARD-1");
        assertThat(nextCheckIn.title()).isEqualTo("新一轮签到成功");
        assertThat(jdbcTemplate.queryForObject("SELECT COUNT(*) FROM attendance_session", Integer.class)).isEqualTo(2);
        assertThat(jdbcTemplate.queryForObject("SELECT COUNT(*) FROM attendance_session WHERE status='COMPLETED'", Integer.class)).isEqualTo(1);
    }

    @Test
    void trailingColonInManualDemoInputIsIgnored() {
        long workerId = createWorker("TEST-WORKER-4", "Worker Test 4", "TEST-ID-4");
        tokenRepository.create(workerId, "TEST-CARD-4");

        assertThat(attendanceService.scan("test-card-4：").title()).isEqualTo("签到成功");
        ageOpenSession();
        assertThat(attendanceService.scan("test-card-4:").title()).isEqualTo("签退成功");
    }

    @Test
    void futureDemoRecordDoesNotTriggerDuplicateWarning() {
        long workerId = createWorker("TEST-WORKER-FUTURE", "Future Demo Worker", "TEST-ID-FUTURE");
        long tokenId = tokenRepository.create(workerId, "TEST-FUTURE-CARD");
        jdbcTemplate.update("INSERT INTO attendance_session(worker_id, token_id, check_in_time, check_out_time, "
                + "status, updated_at) VALUES (?,?,?,?, 'COMPLETED', ?)", workerId, tokenId,
                "2099-10-12T00:00:00Z", "2099-10-12T04:00:00Z", "2099-10-12T04:00:00Z");

        assertThat(attendanceService.scan("TEST-FUTURE-CARD").title()).isEqualTo("签到成功");
    }

    @Test
    void unknownAndRevokedCardsHaveDifferentMessages() {
        assertThat(attendanceService.scan("NOT-A-CARD").message()).isEqualTo("卡号不存在，请重新刷卡");
        long workerId = createWorker("TEST-WORKER-5", "Worker Test 5", "TEST-ID-5");
        long tokenId = tokenRepository.create(workerId, "TEST-CARD-5");
        jdbcTemplate.update("UPDATE identity_token SET active=0 WHERE token_id=?", tokenId);
        assertThat(attendanceService.scan("TEST-CARD-5").message()).isEqualTo("该身份卡已经撤销");
    }

    @Test
    void unknownCardAndInactiveWorkerAreRejected() {
        assertThat(attendanceService.scan("UNKNOWN-CARD").title()).isEqualTo("卡号无法识别");

        long workerId = createWorker("TEST-WORKER-2", "Worker Test 2", "TEST-ID-2");
        tokenRepository.create(workerId, "TEST-CARD-2");
        workerService.setActive(workerId, false);

        assertThat(attendanceService.scan("TEST-CARD-2").message()).contains("已停用");
        assertThat(jdbcTemplate.queryForObject("SELECT COUNT(*) FROM attendance_session", Integer.class)).isZero();
    }

    @Test
    void terminalIsPublicButStillRequiresCsrfForScan() throws Exception {
        mockMvc.perform(get("/attendance")).andExpect(status().isOk());
        mockMvc.perform(post("/attendance").param("tokenValue", "TEST-CARD-1"))
                .andExpect(status().isForbidden());
        mockMvc.perform(post("/attendance").with(csrf()).param("tokenValue", "TEST-CARD-1"))
                .andExpect(status().is3xxRedirection()).andExpect(redirectedUrl("/attendance"));
    }

    @Test
    void attendanceRecordsRequireAdministrator() throws Exception {
        mockMvc.perform(get("/admin/attendance")).andExpect(status().is3xxRedirection());
    }

    @Test
    @WithMockUser(username = "admin", roles = "ADMIN")
    void administratorCanViewAttendanceRecords() throws Exception {
        long workerId = createWorker("TEST-WORKER-3", "Worker Test 3", "TEST-ID-3");
        tokenRepository.create(workerId, "TEST-CARD-3");
        attendanceService.scan("TEST-CARD-3");

        mockMvc.perform(get("/admin/attendance"))
                .andExpect(status().isOk())
                .andExpect(org.springframework.test.web.servlet.result.MockMvcResultMatchers.content()
                        .string(org.hamcrest.Matchers.containsString("Worker Test 3")));
    }

    private long createWorker(String number, String name, String document) {
        WorkerForm form = new WorkerForm();
        form.setWorkerNumber(number);
        form.setFullName(name);
        form.setIdDocumentType("PROGRAM_ID");
        form.setIdDocumentNumber(document);
        form.setContactPhone(null);
        return workerService.create(form);
    }

    private void ageOpenSession() {
        jdbcTemplate.update("UPDATE attendance_session SET check_in_time='2020-01-01T00:00:00Z', "
                + "updated_at='2020-01-01T00:00:00Z' WHERE status='OPEN'");
    }
}
