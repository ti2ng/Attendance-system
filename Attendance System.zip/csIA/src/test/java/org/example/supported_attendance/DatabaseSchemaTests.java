package org.example.supported_attendance;

import java.util.List;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
class DatabaseSchemaTests {

    private static final Set<String> REQUIRED_TABLES = Set.of(
            "staff_account",
            "supported_worker",
            "identity_token",
            "work_period",
            "work_period_worker",
            "attendance",
            "allowance_rule",
            "monthly_allowance",
            "audit_log",
            "attendance_session",
            "attendance_settings",
            "bonus_threshold_settings",
            "monthly_bonus_result",
            "monthly_bonus_daily_detail");

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Test
    void createsRequiredTables() {
        List<String> tables = jdbcTemplate.queryForList(
                "SELECT name FROM sqlite_master WHERE type = 'table'",
                String.class);

        assertThat(tables).containsAll(REQUIRED_TABLES);
    }

    @Test
    void enablesForeignKeyEnforcement() {
        Integer enabled = jdbcTemplate.queryForObject("PRAGMA foreign_keys", Integer.class);
        assertThat(enabled).isEqualTo(1);
    }
}
