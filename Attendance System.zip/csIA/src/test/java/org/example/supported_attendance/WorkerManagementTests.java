package org.example.supported_attendance;

import org.example.supported_attendance.model.Worker;
import org.example.supported_attendance.repository.WorkerRepository;
import org.example.supported_attendance.service.WorkerService;
import org.example.supported_attendance.web.WorkerForm;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.redirectedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
class WorkerManagementTests {

    @Autowired
    private WorkerRepository workerRepository;

    @Autowired
    private WorkerService workerService;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private MockMvc mockMvc;

    @BeforeEach
    void clearWorkers() {
        jdbcTemplate.update("DELETE FROM monthly_bonus_daily_detail");
        jdbcTemplate.update("DELETE FROM monthly_bonus_result");
        jdbcTemplate.update("DELETE FROM attendance_session");
        jdbcTemplate.update("DELETE FROM identity_token");
        jdbcTemplate.update("DELETE FROM supported_worker");
    }

    @Test
    void createsWorkerWithSimulatedIdentityAndMasksSensitiveValues() {
        WorkerForm form = form("WORKER-0001", "Worker A", "DEMO-ID-0001", "DEMO-PHONE-0001");

        long workerId = workerService.create(form);
        Worker worker = workerRepository.findById(workerId).orElseThrow();

        assertThat(worker.fullName()).isEqualTo("Worker A");
        assertThat(worker.idDocumentNumber()).isEqualTo("DEMO-ID-0001");
        assertThat(worker.maskedIdDocumentNumber()).isEqualTo("DEMO-****-0001");
        assertThat(worker.maskedContactPhone()).isEqualTo("DEMO-****-0001");
        assertThat(worker.active()).isTrue();
    }

    @Test
    void duplicateWorkerNumberAndDocumentNumberAreRejected() {
        workerService.create(form("WORKER-0001", "Worker A", "DEMO-ID-0001", "DEMO-PHONE-0001"));

        WorkerForm duplicateNumber = form("WORKER-0001", "Worker B", "DEMO-ID-0002", "DEMO-PHONE-0002");
        org.assertj.core.api.Assertions.assertThatThrownBy(() -> workerService.create(duplicateNumber))
                .hasMessage("该人员编号已存在");

        WorkerForm duplicateDocument = form("WORKER-0002", "Worker B", "DEMO-ID-0001", "DEMO-PHONE-0002");
        org.assertj.core.api.Assertions.assertThatThrownBy(() -> workerService.create(duplicateDocument))
                .hasMessage("该证件号码已存在");
    }

    @Test
    void deactivationPreservesWorkerRowAndCanBeReversed() {
        long workerId = workerService.create(form("WORKER-0001", "Worker A", "DEMO-ID-0001", null));

        workerService.setActive(workerId, false);
        assertThat(workerRepository.findById(workerId).orElseThrow().active()).isFalse();

        workerService.setActive(workerId, true);
        assertThat(workerRepository.findById(workerId).orElseThrow().active()).isTrue();
    }

    @Test
    @WithMockUser(username = "admin", roles = "ADMIN")
    void workerListRequiresAdminAndIsAccessibleToAdministrator() throws Exception {
        mockMvc.perform(get("/admin/workers"))
                .andExpect(status().isOk());
    }

    @Test
    void workerListRequiresAuthentication() throws Exception {
        mockMvc.perform(get("/admin/workers"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/login"));
    }

    @Test
    @WithMockUser(username = "admin", roles = "ADMIN")
    void invalidWorkerFormReturnsValidationError() throws Exception {
        mockMvc.perform(post("/admin/workers")
                        .with(csrf())
                        .param("workerNumber", "")
                        .param("fullName", "")
                        .param("idDocumentType", "NATIONAL_ID")
                        .param("idDocumentNumber", ""))
                .andExpect(status().isOk());
    }

    private static WorkerForm form(String number, String name, String document, String phone) {
        WorkerForm form = new WorkerForm();
        form.setWorkerNumber(number);
        form.setFullName(name);
        form.setIdDocumentType("NATIONAL_ID");
        form.setIdDocumentNumber(document);
        form.setContactPhone(phone);
        return form;
    }
}
