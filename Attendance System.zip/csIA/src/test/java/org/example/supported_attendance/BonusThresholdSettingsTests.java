package org.example.supported_attendance;

import java.math.BigDecimal;

import org.example.supported_attendance.repository.BonusThresholdSettingsRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.redirectedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
class BonusThresholdSettingsTests {
    @Autowired MockMvc mockMvc;
    @Autowired BonusThresholdSettingsRepository repository;

    @BeforeEach
    void reset() { repository.update(240, 15, new BigDecimal("50.00"), new BigDecimal("1000.00")); }

    @Test
    void pageRequiresAdministrator() throws Exception {
        mockMvc.perform(get("/admin/bonus-thresholds"))
                .andExpect(status().is3xxRedirection()).andExpect(redirectedUrl("/login"));
    }

    @Test
    @WithMockUser(username = "admin", roles = "ADMIN")
    void administratorCanViewAndSaveFourThresholds() throws Exception {
        mockMvc.perform(get("/admin/bonus-thresholds")).andExpect(status().isOk());
        mockMvc.perform(post("/admin/bonus-thresholds").with(csrf())
                        .param("dailyWorkMinutesThreshold", "300")
                        .param("monthlyValidDaysThreshold", "16")
                        .param("dailyBonusThreshold", "55.50")
                        .param("monthlyBonusCapThreshold", "1200.00"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/admin/bonus-thresholds"));

        var saved = repository.get();
        assertThat(saved.dailyWorkMinutesThreshold()).isEqualTo(300);
        assertThat(saved.monthlyValidDaysThreshold()).isEqualTo(16);
        assertThat(saved.dailyBonusThreshold()).isEqualByComparingTo("55.50");
        assertThat(saved.monthlyBonusCapThreshold()).isEqualByComparingTo("1200.00");
    }

    @Test
    @WithMockUser(username = "admin", roles = "ADMIN")
    void invalidThresholdsAreNotSaved() throws Exception {
        mockMvc.perform(post("/admin/bonus-thresholds").with(csrf())
                        .param("dailyWorkMinutesThreshold", "0")
                        .param("monthlyValidDaysThreshold", "32")
                        .param("dailyBonusThreshold", "50")
                        .param("monthlyBonusCapThreshold", "1000"))
                .andExpect(status().is3xxRedirection());

        assertThat(repository.get().dailyWorkMinutesThreshold()).isEqualTo(240);
    }
}
