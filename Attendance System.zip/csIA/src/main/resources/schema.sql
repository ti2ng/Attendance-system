PRAGMA foreign_keys = ON;
PRAGMA journal_mode = WAL;

CREATE TABLE IF NOT EXISTS staff_account (
    staff_id       INTEGER PRIMARY KEY AUTOINCREMENT,
    username       TEXT NOT NULL UNIQUE,
    password_hash  TEXT NOT NULL,
    active         INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0, 1)),
    created_at     TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
);

CREATE TABLE IF NOT EXISTS supported_worker (
    worker_id      INTEGER PRIMARY KEY AUTOINCREMENT,
    worker_number  TEXT NOT NULL UNIQUE,
    display_name   TEXT NOT NULL,
    id_document_type TEXT NOT NULL DEFAULT 'OTHER',
    id_document_number TEXT NOT NULL DEFAULT 'DEMO-ID-UNASSIGNED',
    contact_phone  TEXT,
    active         INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0, 1)),
    created_at     TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now')),
    updated_at     TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
);

CREATE TABLE IF NOT EXISTS identity_token (
    token_id       INTEGER PRIMARY KEY AUTOINCREMENT,
    worker_id      INTEGER NOT NULL,
    token_value    TEXT NOT NULL UNIQUE,
    source_type    TEXT NOT NULL DEFAULT 'SIMULATED'
                   CHECK (source_type IN ('SIMULATED', 'RFID')),
    active         INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0, 1)),
    issued_at      TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now')),
    revoked_at     TEXT,
    FOREIGN KEY (worker_id) REFERENCES supported_worker(worker_id)
);

CREATE UNIQUE INDEX IF NOT EXISTS ux_identity_token_active_worker
    ON identity_token(worker_id)
    WHERE active = 1;

CREATE TABLE IF NOT EXISTS attendance_session (
    session_id      INTEGER PRIMARY KEY AUTOINCREMENT,
    worker_id       INTEGER NOT NULL,
    token_id        INTEGER NOT NULL,
    check_in_time   TEXT NOT NULL,
    check_out_time  TEXT,
    status          TEXT NOT NULL DEFAULT 'OPEN'
                    CHECK (status IN ('OPEN', 'COMPLETED')),
    input_source    TEXT NOT NULL DEFAULT 'SIMULATED'
                    CHECK (input_source IN ('SIMULATED', 'RFID')),
    updated_at      TEXT NOT NULL,
    CHECK (check_out_time IS NULL OR check_out_time >= check_in_time),
    FOREIGN KEY (worker_id) REFERENCES supported_worker(worker_id),
    FOREIGN KEY (token_id) REFERENCES identity_token(token_id)
);

CREATE UNIQUE INDEX IF NOT EXISTS ux_attendance_session_open_worker
    ON attendance_session(worker_id)
    WHERE status = 'OPEN';

CREATE INDEX IF NOT EXISTS ix_attendance_session_check_in
    ON attendance_session(check_in_time DESC);

CREATE TABLE IF NOT EXISTS attendance_settings (
    settings_id              INTEGER PRIMARY KEY CHECK (settings_id = 1),
    duplicate_scan_seconds   INTEGER NOT NULL DEFAULT 30 CHECK (duplicate_scan_seconds BETWEEN 1 AND 300),
    minimum_checkout_minutes INTEGER NOT NULL DEFAULT 30 CHECK (minimum_checkout_minutes BETWEEN 1 AND 720),
    updated_at               TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
);

INSERT OR IGNORE INTO attendance_settings
    (settings_id, duplicate_scan_seconds, minimum_checkout_minutes)
VALUES (1, 30, 30);

CREATE TABLE IF NOT EXISTS bonus_threshold_settings (
    settings_id                         INTEGER PRIMARY KEY CHECK (settings_id = 1),
    daily_work_minutes_threshold        INTEGER NOT NULL DEFAULT 240
                                        CHECK (daily_work_minutes_threshold BETWEEN 1 AND 1440),
    monthly_valid_days_threshold        INTEGER NOT NULL DEFAULT 15
                                        CHECK (monthly_valid_days_threshold BETWEEN 1 AND 31),
    daily_bonus_threshold               NUMERIC NOT NULL DEFAULT 50
                                        CHECK (daily_bonus_threshold >= 0),
    monthly_bonus_cap_threshold         NUMERIC NOT NULL DEFAULT 1000
                                        CHECK (monthly_bonus_cap_threshold >= 0),
    updated_at                          TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
);

INSERT OR IGNORE INTO bonus_threshold_settings
    (settings_id, daily_work_minutes_threshold, monthly_valid_days_threshold,
     daily_bonus_threshold, monthly_bonus_cap_threshold)
VALUES (1, 240, 15, 50, 1000);

CREATE TABLE IF NOT EXISTS monthly_bonus_result (
    result_id                         INTEGER PRIMARY KEY AUTOINCREMENT,
    worker_id                         INTEGER NOT NULL,
    year_month                        TEXT NOT NULL,
    daily_work_minutes_threshold      INTEGER NOT NULL,
    monthly_valid_days_threshold      INTEGER NOT NULL,
    daily_bonus_threshold             NUMERIC NOT NULL,
    monthly_bonus_cap_threshold       NUMERIC NOT NULL,
    total_completed_minutes           INTEGER NOT NULL,
    valid_days                        INTEGER NOT NULL,
    raw_bonus                         NUMERIC NOT NULL,
    final_bonus                       NUMERIC NOT NULL,
    qualification_status              TEXT NOT NULL CHECK (qualification_status IN ('QUALIFIED', 'NOT_QUALIFIED')),
    calculated_at                     TEXT NOT NULL,
    UNIQUE (worker_id, year_month),
    FOREIGN KEY (worker_id) REFERENCES supported_worker(worker_id)
);

CREATE TABLE IF NOT EXISTS monthly_bonus_daily_detail (
    detail_id          INTEGER PRIMARY KEY AUTOINCREMENT,
    result_id          INTEGER NOT NULL,
    work_date          TEXT NOT NULL,
    completed_minutes  INTEGER NOT NULL,
    valid_day          INTEGER NOT NULL CHECK (valid_day IN (0, 1)),
    UNIQUE (result_id, work_date),
    FOREIGN KEY (result_id) REFERENCES monthly_bonus_result(result_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS work_period (
    period_id       INTEGER PRIMARY KEY AUTOINCREMENT,
    work_date       TEXT NOT NULL,
    work_type       TEXT NOT NULL DEFAULT 'DAILY_WORK',
    planned_start   TEXT NOT NULL,
    planned_end     TEXT NOT NULL,
    status          TEXT NOT NULL DEFAULT 'DRAFT'
                    CHECK (status IN ('DRAFT', 'OPEN', 'CLOSED')),
    CHECK (planned_end > planned_start)
);

CREATE TABLE IF NOT EXISTS work_period_worker (
    period_id       INTEGER NOT NULL,
    worker_id       INTEGER NOT NULL,
    exempt          INTEGER NOT NULL DEFAULT 0 CHECK (exempt IN (0, 1)),
    exemption_note  TEXT,
    PRIMARY KEY (period_id, worker_id),
    FOREIGN KEY (period_id) REFERENCES work_period(period_id),
    FOREIGN KEY (worker_id) REFERENCES supported_worker(worker_id)
);

CREATE TABLE IF NOT EXISTS attendance (
    attendance_id   INTEGER PRIMARY KEY AUTOINCREMENT,
    period_id       INTEGER NOT NULL,
    worker_id       INTEGER NOT NULL,
    check_in_time   TEXT NOT NULL,
    check_out_time  TEXT,
    duration_minutes INTEGER,
    status          TEXT NOT NULL DEFAULT 'CHECKED_IN',
    input_source    TEXT NOT NULL DEFAULT 'SIMULATED'
                    CHECK (input_source IN ('SIMULATED', 'RFID')),
    updated_at      TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now')),
    UNIQUE (period_id, worker_id),
    CHECK (check_out_time IS NULL OR check_out_time >= check_in_time),
    CHECK (duration_minutes IS NULL OR duration_minutes >= 0),
    FOREIGN KEY (period_id) REFERENCES work_period(period_id),
    FOREIGN KEY (worker_id) REFERENCES supported_worker(worker_id)
);

CREATE TABLE IF NOT EXISTS allowance_rule (
    rule_id             INTEGER PRIMARY KEY AUTOINCREMENT,
    version_name        TEXT NOT NULL UNIQUE,
    effective_from      TEXT NOT NULL,
    base_amount         NUMERIC NOT NULL CHECK (base_amount >= 0),
    minimum_minutes     INTEGER NOT NULL CHECK (minimum_minutes >= 0),
    monthly_cap         NUMERIC NOT NULL CHECK (monthly_cap >= 0),
    attendance_weight   INTEGER NOT NULL CHECK (attendance_weight >= 0),
    duration_weight     INTEGER NOT NULL CHECK (duration_weight >= 0),
    punctuality_weight  INTEGER NOT NULL CHECK (punctuality_weight >= 0),
    CHECK (attendance_weight + duration_weight + punctuality_weight = 100)
);

CREATE TABLE IF NOT EXISTS monthly_allowance (
    allowance_id         INTEGER PRIMARY KEY AUTOINCREMENT,
    worker_id            INTEGER NOT NULL,
    year_month           TEXT NOT NULL,
    rule_id              INTEGER NOT NULL,
    attendance_component NUMERIC NOT NULL,
    duration_component   NUMERIC NOT NULL,
    punctuality_component NUMERIC NOT NULL,
    final_amount         NUMERIC NOT NULL CHECK (final_amount >= 0),
    calculated_at        TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now')),
    stale                INTEGER NOT NULL DEFAULT 0 CHECK (stale IN (0, 1)),
    UNIQUE (worker_id, year_month, rule_id),
    FOREIGN KEY (worker_id) REFERENCES supported_worker(worker_id),
    FOREIGN KEY (rule_id) REFERENCES allowance_rule(rule_id)
);

CREATE TABLE IF NOT EXISTS audit_log (
    audit_id        INTEGER PRIMARY KEY AUTOINCREMENT,
    staff_id        INTEGER,
    entity_type     TEXT NOT NULL,
    entity_id       INTEGER NOT NULL,
    action_type     TEXT NOT NULL,
    old_value       TEXT,
    new_value       TEXT,
    reason          TEXT NOT NULL,
    changed_at      TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now')),
    FOREIGN KEY (staff_id) REFERENCES staff_account(staff_id)
);
