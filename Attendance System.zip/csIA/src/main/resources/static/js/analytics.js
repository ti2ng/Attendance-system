(() => {
    const canvas = document.getElementById("attendanceTrend");
    if (!canvas) return;

    const points = Array.from(document.querySelectorAll("#trendData span")).map((item) => ({
        date: item.dataset.date,
        sessions: Number(item.dataset.sessions),
        valid: Number(item.dataset.valid)
    }));
    if (points.length === 0) return;

    const draw = () => {
        const ratio = window.devicePixelRatio || 1;
        const width = canvas.clientWidth;
        const height = 250;
        canvas.width = width * ratio;
        canvas.height = height * ratio;
        const ctx = canvas.getContext("2d");
        ctx.scale(ratio, ratio);

        const styles = getComputedStyle(document.documentElement);
        const grid = styles.getPropertyValue("--chart-grid").trim();
        const text = styles.getPropertyValue("--chart-text").trim();
        const completed = styles.getPropertyValue("--chart-completed").trim();
        const valid = styles.getPropertyValue("--chart-qualified").trim();
        const margin = { top: 16, right: 18, bottom: 38, left: 36 };
        const plotWidth = width - margin.left - margin.right;
        const plotHeight = height - margin.top - margin.bottom;
        const maxValue = Math.max(1, ...points.flatMap((point) => [point.sessions, point.valid]));

        ctx.font = "12px Segoe UI, Microsoft YaHei, sans-serif";
        ctx.lineWidth = 1;
        ctx.strokeStyle = grid;
        ctx.fillStyle = text;
        for (let i = 0; i <= 4; i++) {
            const y = margin.top + plotHeight * i / 4;
            const label = Math.round(maxValue * (4 - i) / 4);
            ctx.beginPath();
            ctx.moveTo(margin.left, y);
            ctx.lineTo(width - margin.right, y);
            ctx.stroke();
            ctx.fillText(String(label), 8, y + 4);
        }

        const xAt = (index) => margin.left + (points.length === 1 ? plotWidth / 2 : plotWidth * index / (points.length - 1));
        const yAt = (value) => margin.top + plotHeight - value / maxValue * plotHeight;
        const plot = (field, color) => {
            ctx.strokeStyle = color;
            ctx.fillStyle = color;
            ctx.lineWidth = 3;
            ctx.beginPath();
            points.forEach((point, index) => index === 0
                ? ctx.moveTo(xAt(index), yAt(point[field]))
                : ctx.lineTo(xAt(index), yAt(point[field])));
            ctx.stroke();
            points.forEach((point, index) => {
                ctx.beginPath();
                ctx.arc(xAt(index), yAt(point[field]), 3.5, 0, Math.PI * 2);
                ctx.fill();
            });
        };
        plot("sessions", completed);
        plot("valid", valid);

        ctx.fillStyle = text;
        const labelStep = Math.max(1, Math.ceil(points.length / 7));
        points.forEach((point, index) => {
            if (index % labelStep !== 0 && index !== points.length - 1) return;
            ctx.save();
            ctx.translate(xAt(index), height - 12);
            ctx.rotate(-0.35);
            ctx.fillText(point.date.slice(5), -12, 0);
            ctx.restore();
        });
    };

    draw();
    new ResizeObserver(draw).observe(canvas);
})();
