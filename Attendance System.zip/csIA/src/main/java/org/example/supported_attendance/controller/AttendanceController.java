package org.example.supported_attendance.controller;

import org.example.supported_attendance.service.AttendanceService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class AttendanceController {
    private final AttendanceService attendanceService;
    private final int resultDisplaySeconds;

    public AttendanceController(AttendanceService attendanceService,
            @Value("${app.attendance.result-display-seconds:4}") int resultDisplaySeconds) {
        this.attendanceService = attendanceService;
        this.resultDisplaySeconds = resultDisplaySeconds;
    }

    @GetMapping("/attendance")
    public String terminal(Model model) {
        model.addAttribute("resultDisplaySeconds", resultDisplaySeconds);
        return "attendance/index";
    }

    @PostMapping("/attendance")
    public String scan(@RequestParam(defaultValue = "") String tokenValue, RedirectAttributes attributes) {
        attributes.addFlashAttribute("scanResult", attendanceService.scan(tokenValue));
        return "redirect:/attendance";
    }
}
