package org.example.supported_attendance.controller;

import org.example.supported_attendance.repository.WorkerRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HealthController {

    private final WorkerRepository workerRepository;

    public HealthController(WorkerRepository workerRepository) {
        this.workerRepository = workerRepository;
    }

    @GetMapping("/health")
    public String health(Model model) {
        model.addAttribute("status", "OK");
        model.addAttribute("workerCount", workerRepository.countAll());
        return "health";
    }
}
