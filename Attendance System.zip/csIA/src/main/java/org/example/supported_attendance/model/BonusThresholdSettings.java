package org.example.supported_attendance.model;

import java.math.BigDecimal;

public record BonusThresholdSettings(int dailyWorkMinutesThreshold,
        int monthlyValidDaysThreshold, BigDecimal dailyBonusThreshold,
        BigDecimal monthlyBonusCapThreshold, String updatedAt) {
}
