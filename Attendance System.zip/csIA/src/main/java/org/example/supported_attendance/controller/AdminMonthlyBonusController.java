package org.example.supported_attendance.controller;

import java.time.YearMonth;
import org.example.supported_attendance.service.MonthlyBonusService;
import org.example.supported_attendance.service.I18nService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class AdminMonthlyBonusController {
    private final MonthlyBonusService service;
    private final I18nService i18n;

    public AdminMonthlyBonusController(MonthlyBonusService service, I18nService i18n) {
        this.service = service;
        this.i18n = i18n;
    }

    @GetMapping("/admin/bonuses")
    public String list(@RequestParam(required = false) String month, Model model) {
        String selected = service.normalizeMonth(month);
        model.addAttribute("month", selected);
        model.addAttribute("results", service.findByMonth(selected));
        return "admin/bonus/list";
    }

    @PostMapping("/admin/bonuses/calculate")
    public String calculate(@RequestParam String month, RedirectAttributes attributes) {
        try {
            String selected = service.normalizeMonth(month);
            service.calculate(selected);
            attributes.addFlashAttribute("successMessage", i18n.text("message.bonus.calculated", selected));
            return "redirect:/admin/bonuses?month=" + selected;
        } catch (IllegalArgumentException exception) {
            attributes.addFlashAttribute("errorMessage", exception.getMessage());
            return "redirect:/admin/bonuses";
        }
    }

    @GetMapping("/admin/bonuses/{resultId}/details")
    public String details(@PathVariable long resultId, @RequestParam String month, Model model) {
        var result = service.findByMonth(month).stream().filter(item -> item.resultId() == resultId)
                .findFirst().orElseThrow(() -> new IllegalArgumentException(i18n.text("message.bonus.notFound")));
        model.addAttribute("result", result);
        model.addAttribute("details", service.findDetails(resultId));
        return "admin/bonus/details";
    }
}
