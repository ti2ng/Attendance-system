package org.example.supported_attendance.controller;

import org.example.supported_attendance.repository.WorkerRepository;
import org.example.supported_attendance.repository.AttendanceSettingsRepository;
import org.example.supported_attendance.service.AttendanceService;
import org.example.supported_attendance.service.IdentityTokenService;
import org.example.supported_attendance.service.I18nService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class AdminAttendanceController {
    private final AttendanceService attendanceService;
    private final IdentityTokenService tokenService;
    private final WorkerRepository workerRepository;
    private final AttendanceSettingsRepository settingsRepository;
    private final I18nService i18n;

    public AdminAttendanceController(AttendanceService attendanceService, IdentityTokenService tokenService,
            WorkerRepository workerRepository, AttendanceSettingsRepository settingsRepository, I18nService i18n) {
        this.attendanceService = attendanceService;
        this.tokenService = tokenService;
        this.workerRepository = workerRepository;
        this.settingsRepository = settingsRepository;
        this.i18n = i18n;
    }

    @GetMapping("/admin/attendance")
    public String attendance(Model model) {
        model.addAttribute("sessions", attendanceService.findAll());
        model.addAttribute("settings", settingsRepository.get());
        return "admin/attendance/list";
    }

    @PostMapping("/admin/attendance/settings")
    public String updateSettings(@RequestParam int duplicateScanSeconds,
            @RequestParam int minimumCheckoutMinutes, RedirectAttributes attributes) {
        if (duplicateScanSeconds < 1 || duplicateScanSeconds > 300
                || minimumCheckoutMinutes < 1 || minimumCheckoutMinutes > 720) {
            attributes.addFlashAttribute("errorMessage", i18n.text("message.settings.invalid"));
        } else {
            settingsRepository.update(duplicateScanSeconds, minimumCheckoutMinutes);
            attributes.addFlashAttribute("successMessage", i18n.text("message.settings.saved"));
        }
        return "redirect:/admin/attendance";
    }

    @GetMapping("/admin/workers/{workerId}/tokens")
    public String tokens(@PathVariable long workerId, Model model) {
        model.addAttribute("worker", workerRepository.findById(workerId).orElseThrow(() -> new IllegalArgumentException(i18n.text("message.worker.notFound"))));
        model.addAttribute("tokens", tokenService.findForWorker(workerId));
        return "admin/workers/tokens";
    }

    @PostMapping("/admin/workers/{workerId}/tokens")
    public String bind(@PathVariable long workerId, @RequestParam String tokenValue, RedirectAttributes attributes) {
        try {
            tokenService.bind(workerId, tokenValue);
            attributes.addFlashAttribute("successMessage", i18n.text("message.token.bound"));
        } catch (IllegalArgumentException exception) {
            attributes.addFlashAttribute("errorMessage", exception.getMessage());
        }
        return "redirect:/admin/workers/" + workerId + "/tokens";
    }

    @PostMapping("/admin/workers/{workerId}/tokens/{tokenId}/revoke")
    public String revoke(@PathVariable long workerId, @PathVariable long tokenId, RedirectAttributes attributes) {
        tokenService.revoke(workerId, tokenId);
        attributes.addFlashAttribute("successMessage", i18n.text("message.token.revoked"));
        return "redirect:/admin/workers/" + workerId + "/tokens";
    }
}
