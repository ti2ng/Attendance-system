package org.example.supported_attendance.model;

public record IdentityToken(long tokenId, long workerId, String workerNumber,
        String workerName, String tokenValue, boolean active, String issuedAt, String revokedAt) {

    public String maskedValue() {
        if (tokenValue == null || tokenValue.length() <= 6) {
            return tokenValue;
        }
        return tokenValue.substring(0, 5) + "****" + tokenValue.substring(tokenValue.length() - 4);
    }
}
