package org.example.supported_attendance.model;

import java.math.BigDecimal;

public record MonthlyBonusResult(long resultId, long workerId, String workerNumber, String workerName,
        String yearMonth, int dailyWorkMinutesThreshold, int monthlyValidDaysThreshold,
        BigDecimal dailyBonusThreshold, BigDecimal monthlyBonusCapThreshold,
        long totalCompletedMinutes, int validDays, BigDecimal rawBonus, BigDecimal finalBonus,
        String qualificationStatus, String calculatedAt) {

    public boolean qualified() { return "QUALIFIED".equals(qualificationStatus); }
}
