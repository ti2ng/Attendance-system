package org.example.supported_attendance.service;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.example.supported_attendance.model.AttendanceSession;
import org.example.supported_attendance.model.IdentityToken;
import org.example.supported_attendance.repository.AttendanceRepository;
import org.example.supported_attendance.repository.AttendanceSettingsRepository;
import org.example.supported_attendance.repository.IdentityTokenRepository;
import org.example.supported_attendance.repository.WorkerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AttendanceService {
    private static final DateTimeFormatter DISPLAY_TIME = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")
            .withZone(ZoneId.systemDefault());

    private final IdentityTokenRepository tokenRepository;
    private final AttendanceRepository attendanceRepository;
    private final WorkerRepository workerRepository;
    private final Clock clock;
    private final AttendanceSettingsRepository settingsRepository;
    private final I18nService i18n;

    @Autowired
    public AttendanceService(IdentityTokenRepository tokenRepository, AttendanceRepository attendanceRepository,
            WorkerRepository workerRepository, AttendanceSettingsRepository settingsRepository, I18nService i18n) {
        this(tokenRepository, attendanceRepository, workerRepository, settingsRepository, i18n, Clock.systemUTC());
    }

    AttendanceService(IdentityTokenRepository tokenRepository, AttendanceRepository attendanceRepository,
            WorkerRepository workerRepository, AttendanceSettingsRepository settingsRepository,
            I18nService i18n, Clock clock) {
        this.tokenRepository = tokenRepository;
        this.attendanceRepository = attendanceRepository;
        this.workerRepository = workerRepository;
        this.settingsRepository = settingsRepository;
        this.clock = clock;
        this.i18n = i18n;
    }

    @Transactional
    public AttendanceResult scan(String rawToken) {
        String value = normalizeToken(rawToken);
        if (value.isEmpty()) return failure(i18n.text("scan.enterCard"));

        IdentityToken token = tokenRepository.findByValue(value).orElse(null);
        if (token == null) return failure(i18n.text("scan.cardNotFound"));
        if (!token.active()) return result("error", i18n.text("scan.rejected"), i18n.text("scan.revoked"), token, Instant.now(clock));
        if (!workerRepository.findById(token.workerId()).orElseThrow().active()) {
            return result("error", i18n.text("scan.rejected"), i18n.text("scan.workerInactive"), token, Instant.now(clock));
        }

        Instant now = Instant.now(clock);
        var settings = settingsRepository.get();
        long duplicateSeconds = settings.duplicateScanSeconds();
        long minimumCheckoutSeconds = settings.minimumCheckoutMinutes() * 60L;
        // Demo data can include future dates; those records must not make today's scan look duplicated.
        AttendanceSession latest = attendanceRepository.findLatestForTokenAtOrBefore(token.tokenId(), now.toString())
                .orElse(null);
        if (latest != null && Duration.between(Instant.parse(latest.updatedAt()), now).getSeconds() < duplicateSeconds) {
            return result("warning", i18n.text("scan.duplicate"), i18n.text("scan.duplicate.detail"), token, now);
        }

        AttendanceSession open = attendanceRepository.findOpenForWorker(token.workerId()).orElse(null);
        if (open == null) {
            boolean hasCompletedHistory = latest != null && "COMPLETED".equals(latest.status());
            attendanceRepository.checkIn(token.workerId(), token.tokenId(), now.toString());
            return result("success", i18n.text(hasCompletedHistory ? "scan.newCheckIn" : "scan.checkIn"),
                    i18n.text(hasCompletedHistory ? "scan.newCheckIn.detail" : "scan.checkIn.detail"), token, now);
        }

        long elapsed = Duration.between(Instant.parse(open.checkInTime()), now).getSeconds();
        if (elapsed < minimumCheckoutSeconds) {
            long remaining = minimumCheckoutSeconds - elapsed;
            return result("warning", i18n.text("scan.alreadyCheckedIn"), i18n.text("scan.tooEarly", remaining), token, now);
        }
        attendanceRepository.checkOut(open.sessionId(), now.toString());
        return result("success", i18n.text("scan.checkOut"), i18n.text("scan.checkOut.detail"), token, now);
    }

    public List<AttendanceSession> findAll() { return attendanceRepository.findAll(); }

    private String normalizeToken(String rawToken) {
        if (rawToken == null) {
            return "";
        }
        String value = rawToken.replaceAll("[\\s\\uFEFF]+", "").toUpperCase();
        // Tolerate punctuation added while copying a demonstration card number.
        value = value.replaceFirst("[:：，,。.!！?？]+$", "");
        return value;
    }

    private AttendanceResult failure(String message) {
        return new AttendanceResult("error", i18n.text("scan.unrecognized"), message, null, null, DISPLAY_TIME.format(Instant.now(clock)));
    }

    private AttendanceResult result(String type, String title, String message, IdentityToken token, Instant time) {
        return new AttendanceResult(type, title, message, token.workerName(), token.workerNumber(), DISPLAY_TIME.format(time));
    }
}
