package org.example.supported_attendance.model;

public record AttendanceSettings(int duplicateScanSeconds, int minimumCheckoutMinutes, String updatedAt) {
}
