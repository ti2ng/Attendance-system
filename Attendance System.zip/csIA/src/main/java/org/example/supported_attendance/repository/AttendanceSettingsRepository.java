package org.example.supported_attendance.repository;

import org.example.supported_attendance.model.AttendanceSettings;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class AttendanceSettingsRepository {
    private final JdbcTemplate jdbcTemplate;

    public AttendanceSettingsRepository(JdbcTemplate jdbcTemplate) { this.jdbcTemplate = jdbcTemplate; }

    public AttendanceSettings get() {
        return jdbcTemplate.queryForObject(
                "SELECT duplicate_scan_seconds, minimum_checkout_minutes, updated_at "
                        + "FROM attendance_settings WHERE settings_id=1",
                (rs, row) -> new AttendanceSettings(rs.getInt("duplicate_scan_seconds"),
                        rs.getInt("minimum_checkout_minutes"), rs.getString("updated_at")));
    }

    public void update(int duplicateSeconds, int minimumMinutes) {
        jdbcTemplate.update("UPDATE attendance_settings SET duplicate_scan_seconds=?, "
                        + "minimum_checkout_minutes=?, updated_at=strftime('%Y-%m-%dT%H:%M:%SZ','now') "
                        + "WHERE settings_id=1",
                duplicateSeconds, minimumMinutes);
    }
}
