package org.example.supported_attendance.config;

import java.time.Instant;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.ZoneId;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.annotation.Order;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

/** Adds clearly synthetic records for the local school-project demonstration. */
@Component
@Order(1)
public class DemoWorkerDataInitializer implements ApplicationRunner {
    private static final ZoneId BUSINESS_ZONE = ZoneId.of("Asia/Shanghai");
    private static final YearMonth DEMO_MONTH = YearMonth.of(2026, 9);

    private final JdbcTemplate jdbcTemplate;
    private final boolean enabled;

    public DemoWorkerDataInitializer(
            JdbcTemplate jdbcTemplate,
            @Value("${app.demo-data.enabled:true}") boolean enabled) {
        this.jdbcTemplate = jdbcTemplate;
        this.enabled = enabled;
    }

    @Override
    public void run(ApplicationArguments arguments) {
        if (!enabled) {
            return;
        }

        removeFutureDemoAttendance();

        insert("DEMO-WORKER-001", "Worker A", "PROGRAM_ID", "DEMO-ID-0001", "DEMO-PHONE-0001", true);
        insert("DEMO-WORKER-002", "Worker B", "PROGRAM_ID", "DEMO-ID-0002", "DEMO-PHONE-0002", true);
        insert("DEMO-WORKER-003", "Worker C", "PROGRAM_ID", "DEMO-ID-0003", "DEMO-PHONE-0003", true);
        insert("DEMO-WORKER-004", "Worker D", "PROGRAM_ID", "DEMO-ID-0004", "DEMO-PHONE-0004", false);
        insert("DEMO-WORKER-005", "Worker E", "PROGRAM_ID", "DEMO-ID-0005", "DEMO-PHONE-0005", true);
        insert("DEMO-WORKER-006", "Worker F", "PROGRAM_ID", "DEMO-ID-0006", "DEMO-PHONE-0006", true);
        insert("DEMO-WORKER-007", "Worker G", "PROGRAM_ID", "DEMO-ID-0007", "DEMO-PHONE-0007", true);
        insert("DEMO-WORKER-008", "Worker H", "PROGRAM_ID", "DEMO-ID-0008", "DEMO-PHONE-0008", true);
        insert("DEMO-WORKER-009", "Worker I", "PROGRAM_ID", "DEMO-ID-0009", "DEMO-PHONE-0009", true);
        insert("DEMO-WORKER-010", "Worker J", "PROGRAM_ID", "DEMO-ID-0010", "DEMO-PHONE-0010", true);
        insert("DEMO-WORKER-011", "Worker K", "PROGRAM_ID", "DEMO-ID-0011", "DEMO-PHONE-0011", true);
        insert("DEMO-WORKER-012", "Worker L", "PROGRAM_ID", "DEMO-ID-0012", "DEMO-PHONE-0012", true);

        bindDemoCard("DEMO-WORKER-001", "DEMO-CARD-1001");
        bindDemoCard("DEMO-WORKER-002", "DEMO-CARD-1002");
        bindDemoCard("DEMO-WORKER-003", "DEMO-CARD-1003");
        bindDemoCard("DEMO-WORKER-004", "DEMO-CARD-1004");
        bindDemoCard("DEMO-WORKER-005", "DEMO-CARD-1005");
        bindDemoCard("DEMO-WORKER-006", "DEMO-CARD-1006");
        bindDemoCard("DEMO-WORKER-007", "DEMO-CARD-1007");
        bindDemoCard("DEMO-WORKER-008", "DEMO-CARD-1008");
        bindDemoCard("DEMO-WORKER-009", "DEMO-CARD-1009");
        bindDemoCard("DEMO-WORKER-010", "DEMO-CARD-1010");
        bindDemoCard("DEMO-WORKER-011", "DEMO-CARD-1011");
        bindDemoCard("DEMO-WORKER-012", "DEMO-CARD-1012");

        // September 2026 is complete, so every generated attendance record is historical.
        insertDemoWeekdays("DEMO-WORKER-001", "DEMO-CARD-1001", 0, 18, 240);
        insertDemoWeekdays("DEMO-WORKER-002", "DEMO-CARD-1002", 2, 12, 240);
        insertDemoWeekdays("DEMO-WORKER-003", "DEMO-CARD-1003", 0, 21, 240);
        insertDemoWeekdays("DEMO-WORKER-004", "DEMO-CARD-1004", 0, 3, 240);
        insertDemoWeekdays("DEMO-WORKER-005", "DEMO-CARD-1005", 0, 5, 180);
        insertDemoWeekdays("DEMO-WORKER-006", "DEMO-CARD-1006", 2, 8, 260);
        insertDemoWeekdays("DEMO-WORKER-007", "DEMO-CARD-1007", 0, 14, 300);
        insertDemoWeekdays("DEMO-WORKER-008", "DEMO-CARD-1008", 0, 15, 240);
        insertDemoWeekdays("DEMO-WORKER-009", "DEMO-CARD-1009", 1, 16, 360);
        insertDemoWeekdays("DEMO-WORKER-010", "DEMO-CARD-1010", 0, 19, 220);
        insertDemoWeekdays("DEMO-WORKER-011", "DEMO-CARD-1011", 0, 20, 480);
        insertDemoWeekdays("DEMO-WORKER-012", "DEMO-CARD-1012", 0, 22, 275);
    }

    private void insert(String workerNumber, String fullName, String documentType,
            String documentNumber, String phone, boolean active) {
        jdbcTemplate.update(
                "INSERT OR IGNORE INTO supported_worker "
                        + "(worker_number, display_name, id_document_type, id_document_number, "
                        + "contact_phone, active) VALUES (?, ?, ?, ?, ?, ?)",
                workerNumber, fullName, documentType, documentNumber, phone, active ? 1 : 0);
    }

    private void bindDemoCard(String workerNumber, String tokenValue) {
        jdbcTemplate.update(
                "INSERT OR IGNORE INTO identity_token (worker_id, token_value, source_type) "
                        + "SELECT worker_id, ?, 'SIMULATED' FROM supported_worker WHERE worker_number = ?",
                tokenValue, workerNumber);
    }

    private void insertDemoWeekdays(String workerNumber, String tokenValue,
            int skippedWeekdays, int numberOfDays, int minutes) {
        LocalDate date = DEMO_MONTH.atDay(1);
        int skipped = 0;
        int inserted = 0;
        while (inserted < numberOfDays && YearMonth.from(date).equals(DEMO_MONTH)) {
            boolean weekday = date.getDayOfWeek().getValue() <= 5;
            if (weekday && skipped < skippedWeekdays) {
                skipped++;
            } else if (weekday) {
                insertDemoDay(workerNumber, tokenValue, date, minutes);
                inserted++;
            }
            date = date.plusDays(1);
        }
    }

    private void insertDemoDay(String workerNumber, String tokenValue, LocalDate date, int minutes) {
        Instant checkIn = date.atTime(8, 30).atZone(BUSINESS_ZONE).toInstant();
        Instant checkOut = checkIn.plusSeconds(minutes * 60L);
        jdbcTemplate.update(
                "INSERT INTO attendance_session "
                        + "(worker_id, token_id, check_in_time, check_out_time, status, input_source, updated_at) "
                        + "SELECT w.worker_id, t.token_id, ?, ?, 'COMPLETED', 'SIMULATED', ? "
                        + "FROM supported_worker w JOIN identity_token t ON t.worker_id=w.worker_id "
                        + "WHERE w.worker_number=? AND t.token_value=? "
                        + "AND NOT EXISTS (SELECT 1 FROM attendance_session a "
                        + "WHERE a.worker_id=w.worker_id AND a.check_in_time=?)",
                checkIn.toString(), checkOut.toString(), checkOut.toString(),
                workerNumber, tokenValue, checkIn.toString());
    }

    private void removeFutureDemoAttendance() {
        String now = Instant.now().toString();
        jdbcTemplate.update("DELETE FROM attendance_session WHERE check_in_time>? AND token_id IN ("
                + "SELECT token_id FROM identity_token WHERE token_value LIKE 'DEMO-CARD-%')", now);
    }
}
