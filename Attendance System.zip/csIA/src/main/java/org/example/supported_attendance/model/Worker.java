package org.example.supported_attendance.model;

public record Worker(
        long workerId,
        String workerNumber,
        String fullName,
        String idDocumentType,
        String idDocumentNumber,
        String contactPhone,
        boolean active,
        String createdAt,
        String updatedAt) {

    public String maskedIdDocumentNumber() {
        return mask(idDocumentNumber);
    }

    public String maskedContactPhone() {
        return contactPhone == null || contactPhone.isBlank() ? "-" : mask(contactPhone);
    }

    private static String mask(String value) {
        if (value == null || value.length() <= 8) {
            return value == null ? "" : value;
        }
        return value.substring(0, Math.min(5, value.length()))
                + "****"
                + value.substring(value.length() - 5);
    }
}
