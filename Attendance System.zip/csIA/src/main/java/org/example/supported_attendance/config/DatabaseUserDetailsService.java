package org.example.supported_attendance.config;

import org.example.supported_attendance.repository.StaffAccountRepository;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class DatabaseUserDetailsService implements UserDetailsService {

    private final StaffAccountRepository staffAccountRepository;

    public DatabaseUserDetailsService(StaffAccountRepository staffAccountRepository) {
        this.staffAccountRepository = staffAccountRepository;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        var account = staffAccountRepository.findByUsername(username)
                .orElseThrow(() -> new UsernameNotFoundException("Administrator account was not found"));

        return User.withUsername(account.username())
                .password(account.passwordHash())
                .roles("ADMIN")
                .disabled(!account.active())
                .build();
    }
}
