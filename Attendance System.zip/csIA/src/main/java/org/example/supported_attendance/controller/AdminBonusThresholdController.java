package org.example.supported_attendance.controller;

import java.math.BigDecimal;

import org.example.supported_attendance.repository.BonusThresholdSettingsRepository;
import org.example.supported_attendance.service.I18nService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class AdminBonusThresholdController {
    private final BonusThresholdSettingsRepository repository;
    private final I18nService i18n;

    public AdminBonusThresholdController(BonusThresholdSettingsRepository repository, I18nService i18n) {
        this.repository = repository;
        this.i18n = i18n;
    }

    @GetMapping("/admin/bonus-thresholds")
    public String page(Model model) {
        model.addAttribute("thresholds", repository.get());
        return "admin/bonus/thresholds";
    }

    @PostMapping("/admin/bonus-thresholds")
    public String update(@RequestParam int dailyWorkMinutesThreshold,
            @RequestParam int monthlyValidDaysThreshold,
            @RequestParam BigDecimal dailyBonusThreshold,
            @RequestParam BigDecimal monthlyBonusCapThreshold,
            RedirectAttributes attributes) {
        String error = validate(dailyWorkMinutesThreshold, monthlyValidDaysThreshold,
                dailyBonusThreshold, monthlyBonusCapThreshold);
        if (error != null) {
            attributes.addFlashAttribute("errorMessage", error);
        } else {
            repository.update(dailyWorkMinutesThreshold, monthlyValidDaysThreshold,
                    dailyBonusThreshold, monthlyBonusCapThreshold);
            attributes.addFlashAttribute("successMessage", i18n.text("message.threshold.saved"));
        }
        return "redirect:/admin/bonus-thresholds";
    }

    private String validate(int dailyMinutes, int monthlyDays, BigDecimal dailyBonus, BigDecimal monthlyCap) {
        if (dailyMinutes < 1 || dailyMinutes > 1440) return i18n.text("message.threshold.dailyMinutes");
        if (monthlyDays < 1 || monthlyDays > 31) return i18n.text("message.threshold.monthlyDays");
        if (dailyBonus == null || dailyBonus.signum() < 0 || dailyBonus.scale() > 2) return i18n.text("message.threshold.dailyBonus");
        if (monthlyCap == null || monthlyCap.signum() < 0 || monthlyCap.scale() > 2) return i18n.text("message.threshold.monthlyCap");
        return null;
    }
}
