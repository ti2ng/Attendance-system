package org.example.supported_attendance.config;

import org.example.supported_attendance.repository.StaffAccountRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class AdminAccountInitializer implements ApplicationRunner {

    private final StaffAccountRepository staffAccountRepository;
    private final PasswordEncoder passwordEncoder;
    private final String initialUsername;
    private final String initialPassword;

    public AdminAccountInitializer(
            StaffAccountRepository staffAccountRepository,
            PasswordEncoder passwordEncoder,
            @Value("${app.admin.initial-username}") String initialUsername,
            @Value("${app.admin.initial-password}") String initialPassword) {
        this.staffAccountRepository = staffAccountRepository;
        this.passwordEncoder = passwordEncoder;
        this.initialUsername = initialUsername;
        this.initialPassword = initialPassword;
    }

    @Override
    public void run(ApplicationArguments arguments) {
        if (initialUsername.isBlank() || initialPassword.isBlank()) {
            throw new IllegalStateException("Initial administrator username and password must not be blank");
        }

        staffAccountRepository.createIfMissing(
                initialUsername.trim(),
                passwordEncoder.encode(initialPassword));
    }
}
