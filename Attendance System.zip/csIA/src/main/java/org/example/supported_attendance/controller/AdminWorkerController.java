package org.example.supported_attendance.controller;

import jakarta.validation.Valid;

import org.example.supported_attendance.service.DuplicateWorkerFieldException;
import org.example.supported_attendance.service.WorkerService;
import org.example.supported_attendance.service.I18nService;
import org.example.supported_attendance.web.WorkerForm;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class AdminWorkerController {

    private final WorkerService workerService;
    private final I18nService i18n;

    public AdminWorkerController(WorkerService workerService, I18nService i18n) {
        this.workerService = workerService;
        this.i18n = i18n;
    }

    @GetMapping("/admin/workers")
    public String list(@RequestParam(defaultValue = "") String q, Model model) {
        model.addAttribute("workers", workerService.search(q));
        model.addAttribute("query", q);
        return "admin/workers/list";
    }

    @GetMapping("/admin/workers/new")
    public String newForm(Model model) {
        WorkerForm form = new WorkerForm();
        form.setIdDocumentType("NATIONAL_ID");
        model.addAttribute("workerForm", form);
        model.addAttribute("editing", false);
        return "admin/workers/form";
    }

    @PostMapping("/admin/workers")
    public String create(
            @Valid @ModelAttribute("workerForm") WorkerForm form,
            BindingResult bindingResult,
            Model model,
            RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            model.addAttribute("editing", false);
            return "admin/workers/form";
        }
        try {
            workerService.create(form);
        } catch (DuplicateWorkerFieldException exception) {
            bindingResult.rejectValue(exception.getField(), "duplicate", exception.getMessage());
            model.addAttribute("editing", false);
            return "admin/workers/form";
        }
        redirectAttributes.addFlashAttribute("successMessage", i18n.text("message.worker.created"));
        return "redirect:/admin/workers";
    }

    @GetMapping("/admin/workers/{workerId}/edit")
    public String editForm(@PathVariable long workerId, Model model) {
        model.addAttribute("workerForm", workerService.toForm(workerId));
        model.addAttribute("editing", true);
        model.addAttribute("workerId", workerId);
        return "admin/workers/form";
    }

    @PostMapping("/admin/workers/{workerId}")
    public String update(
            @PathVariable long workerId,
            @Valid @ModelAttribute("workerForm") WorkerForm form,
            BindingResult bindingResult,
            Model model,
            RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            model.addAttribute("editing", true);
            model.addAttribute("workerId", workerId);
            return "admin/workers/form";
        }
        try {
            workerService.update(workerId, form);
        } catch (DuplicateWorkerFieldException exception) {
            bindingResult.rejectValue(exception.getField(), "duplicate", exception.getMessage());
            model.addAttribute("editing", true);
            model.addAttribute("workerId", workerId);
            return "admin/workers/form";
        }
        redirectAttributes.addFlashAttribute("successMessage", i18n.text("message.worker.updated"));
        return "redirect:/admin/workers";
    }

    @PostMapping("/admin/workers/{workerId}/deactivate")
    public String deactivate(@PathVariable long workerId, RedirectAttributes redirectAttributes) {
        workerService.setActive(workerId, false);
        redirectAttributes.addFlashAttribute("successMessage", i18n.text("message.worker.deactivated"));
        return "redirect:/admin/workers";
    }

    @PostMapping("/admin/workers/{workerId}/activate")
    public String activate(@PathVariable long workerId, RedirectAttributes redirectAttributes) {
        workerService.setActive(workerId, true);
        redirectAttributes.addFlashAttribute("successMessage", i18n.text("message.worker.activated"));
        return "redirect:/admin/workers";
    }
}
