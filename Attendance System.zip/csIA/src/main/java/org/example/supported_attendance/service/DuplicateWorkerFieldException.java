package org.example.supported_attendance.service;

public class DuplicateWorkerFieldException extends RuntimeException {

    private final String field;

    public DuplicateWorkerFieldException(String field, String message) {
        super(message);
        this.field = field;
    }

    public String getField() {
        return field;
    }
}
