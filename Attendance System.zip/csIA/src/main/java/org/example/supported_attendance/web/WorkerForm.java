package org.example.supported_attendance.web;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class WorkerForm {

    @NotBlank(message = "{validation.workerNumber.required}")
    @Size(max = 50, message = "{validation.workerNumber.size}")
    private String workerNumber;

    @NotBlank(message = "{validation.fullName.required}")
    @Size(max = 100, message = "{validation.fullName.size}")
    private String fullName;

    @NotBlank(message = "{validation.documentType.required}")
    @Size(max = 30, message = "{validation.documentType.size}")
    private String idDocumentType;

    @NotBlank(message = "{validation.documentNumber.required}")
    @Size(max = 80, message = "{validation.documentNumber.size}")
    private String idDocumentNumber;

    @Size(max = 40, message = "{validation.contact.size}")
    private String contactPhone;

    public String getWorkerNumber() { return workerNumber; }
    public void setWorkerNumber(String workerNumber) { this.workerNumber = workerNumber; }
    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }
    public String getIdDocumentType() { return idDocumentType; }
    public void setIdDocumentType(String idDocumentType) { this.idDocumentType = idDocumentType; }
    public String getIdDocumentNumber() { return idDocumentNumber; }
    public void setIdDocumentNumber(String idDocumentNumber) { this.idDocumentNumber = idDocumentNumber; }
    public String getContactPhone() { return contactPhone; }
    public void setContactPhone(String contactPhone) { this.contactPhone = contactPhone; }

    public void trimValues() {
        workerNumber = trim(workerNumber);
        fullName = trim(fullName);
        idDocumentType = trim(idDocumentType);
        idDocumentNumber = trim(idDocumentNumber);
        contactPhone = trim(contactPhone);
    }

    private static String trim(String value) {
        return value == null ? null : value.trim();
    }
}
