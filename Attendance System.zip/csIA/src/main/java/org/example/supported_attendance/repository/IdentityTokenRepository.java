package org.example.supported_attendance.repository;

import java.util.List;
import java.util.Optional;

import org.example.supported_attendance.model.IdentityToken;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class IdentityTokenRepository {
    private final JdbcTemplate jdbcTemplate;

    public IdentityTokenRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public List<IdentityToken> findForWorker(long workerId) {
        return jdbcTemplate.query("SELECT t.*, w.worker_number, w.display_name FROM identity_token t "
                        + "JOIN supported_worker w ON w.worker_id=t.worker_id WHERE t.worker_id=? "
                        + "ORDER BY t.active DESC, t.issued_at DESC", this::map, workerId);
    }

    public List<IdentityToken> findAll() {
        return jdbcTemplate.query("SELECT t.*, w.worker_number, w.display_name FROM identity_token t "
                + "JOIN supported_worker w ON w.worker_id=t.worker_id ORDER BY t.active DESC, w.worker_number", this::map);
    }

    public Optional<IdentityToken> findActiveByValue(String value) {
        return jdbcTemplate.query("SELECT t.*, w.worker_number, w.display_name FROM identity_token t "
                        + "JOIN supported_worker w ON w.worker_id=t.worker_id "
                        + "WHERE t.token_value=? AND t.active=1", this::map, value).stream().findFirst();
    }

    public Optional<IdentityToken> findByValue(String value) {
        return jdbcTemplate.query("SELECT t.*, w.worker_number, w.display_name FROM identity_token t "
                        + "JOIN supported_worker w ON w.worker_id=t.worker_id WHERE t.token_value=?",
                this::map, value).stream().findFirst();
    }

    public long create(long workerId, String value) {
        jdbcTemplate.update("INSERT INTO identity_token(worker_id, token_value, source_type) VALUES (?, ?, 'SIMULATED')",
                workerId, value);
        Long id = jdbcTemplate.queryForObject("SELECT last_insert_rowid()", Long.class);
        return id == null ? 0 : id;
    }

    public int revoke(long tokenId) {
        return jdbcTemplate.update("UPDATE identity_token SET active=0, revoked_at=strftime('%Y-%m-%dT%H:%M:%SZ','now') "
                + "WHERE token_id=?", tokenId);
    }

    private IdentityToken map(java.sql.ResultSet rs, int row) throws java.sql.SQLException {
        return new IdentityToken(rs.getLong("token_id"), rs.getLong("worker_id"), rs.getString("worker_number"),
                rs.getString("display_name"), rs.getString("token_value"), rs.getBoolean("active"),
                rs.getString("issued_at"), rs.getString("revoked_at"));
    }
}
