package org.example.supported_attendance.controller;

import org.example.supported_attendance.repository.WorkerRepository;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class AdminController {

    private final WorkerRepository workerRepository;

    public AdminController(WorkerRepository workerRepository) {
        this.workerRepository = workerRepository;
    }

    @GetMapping("/admin/dashboard")
    public String dashboard(Authentication authentication, Model model) {
        model.addAttribute("username", authentication.getName());
        model.addAttribute("workerCount", workerRepository.countAll());
        return "admin/dashboard";
    }
}
