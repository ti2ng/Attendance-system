package org.example.supported_attendance.repository;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class AnalyticsRepository {
    public record DailyAttendance(String date, int completedSessions, int validWorkers) {}

    private final JdbcTemplate jdbcTemplate;

    public AnalyticsRepository(JdbcTemplate jdbcTemplate) { this.jdbcTemplate = jdbcTemplate; }

    public List<DailyAttendance> dailyAttendance(String start, String end, int dailyMinutes) {
        return jdbcTemplate.query(
                "SELECT work_date, SUM(sessions) sessions, "
                        + "SUM(CASE WHEN completed_minutes>=? THEN 1 ELSE 0 END) valid_workers FROM ("
                        + "SELECT date(datetime(a.check_in_time), '+8 hours') work_date, a.worker_id, COUNT(*) sessions, "
                        + "CAST(ROUND(SUM((julianday(a.check_out_time)-julianday(a.check_in_time))*1440)) AS INTEGER) completed_minutes "
                        + "FROM attendance_session a WHERE a.status='COMPLETED' "
                        + "AND a.check_in_time>=? AND a.check_in_time<? GROUP BY work_date, a.worker_id"
                        + ") daily_worker GROUP BY work_date ORDER BY work_date",
                (rs, row) -> new DailyAttendance(rs.getString("work_date"), rs.getInt("sessions"),
                        rs.getInt("valid_workers")), dailyMinutes, start, end);
    }
}
