package org.example.supported_attendance.service;

public record AttendanceResult(String type, String title, String message,
        String workerName, String workerNumber, String occurredAt) {
}
