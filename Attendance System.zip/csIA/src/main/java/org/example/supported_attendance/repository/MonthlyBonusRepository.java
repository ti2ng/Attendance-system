package org.example.supported_attendance.repository;

import java.math.BigDecimal;
import java.util.List;

import org.example.supported_attendance.model.BonusDailyDetail;
import org.example.supported_attendance.model.MonthlyBonusResult;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class MonthlyBonusRepository {
    private final JdbcTemplate jdbcTemplate;

    public MonthlyBonusRepository(JdbcTemplate jdbcTemplate) { this.jdbcTemplate = jdbcTemplate; }

    public List<MonthlyBonusResult> findByMonth(String month) {
        return jdbcTemplate.query("SELECT r.*, w.worker_number, w.display_name FROM monthly_bonus_result r "
                        + "JOIN supported_worker w ON w.worker_id=r.worker_id WHERE r.year_month=? "
                        + "ORDER BY w.worker_number",
                (rs, row) -> new MonthlyBonusResult(rs.getLong("result_id"), rs.getLong("worker_id"),
                        rs.getString("worker_number"), rs.getString("display_name"), rs.getString("year_month"),
                        rs.getInt("daily_work_minutes_threshold"), rs.getInt("monthly_valid_days_threshold"),
                        rs.getBigDecimal("daily_bonus_threshold"), rs.getBigDecimal("monthly_bonus_cap_threshold"),
                        rs.getLong("total_completed_minutes"), rs.getInt("valid_days"), rs.getBigDecimal("raw_bonus"),
                        rs.getBigDecimal("final_bonus"), rs.getString("qualification_status"),
                        rs.getString("calculated_at")), month);
    }

    public List<BonusDailyDetail> findDetails(long resultId) {
        return jdbcTemplate.query("SELECT work_date, completed_minutes, valid_day "
                        + "FROM monthly_bonus_daily_detail WHERE result_id=? ORDER BY work_date",
                (rs, row) -> new BonusDailyDetail(rs.getString("work_date"), rs.getLong("completed_minutes"),
                        rs.getBoolean("valid_day")), resultId);
    }

    public long replace(long workerId, String month, int dailyMinutes, int monthlyDays,
            BigDecimal dailyBonus, BigDecimal cap, long totalMinutes, int validDays,
            BigDecimal rawBonus, BigDecimal finalBonus, String qualification, String calculatedAt) {
        jdbcTemplate.update("DELETE FROM monthly_bonus_result WHERE worker_id=? AND year_month=?", workerId, month);
        jdbcTemplate.update("INSERT INTO monthly_bonus_result(worker_id,year_month,daily_work_minutes_threshold,"
                        + "monthly_valid_days_threshold,daily_bonus_threshold,monthly_bonus_cap_threshold,"
                        + "total_completed_minutes,valid_days,raw_bonus,final_bonus,qualification_status,calculated_at) "
                        + "VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                workerId, month, dailyMinutes, monthlyDays, dailyBonus, cap, totalMinutes, validDays,
                rawBonus, finalBonus, qualification, calculatedAt);
        Long id = jdbcTemplate.queryForObject("SELECT last_insert_rowid()", Long.class);
        return id == null ? 0 : id;
    }

    public void addDetail(long resultId, BonusDailyDetail detail) {
        jdbcTemplate.update("INSERT INTO monthly_bonus_daily_detail(result_id,work_date,completed_minutes,valid_day) "
                        + "VALUES (?,?,?,?)", resultId, detail.workDate(), detail.completedMinutes(),
                detail.validDay() ? 1 : 0);
    }
}
