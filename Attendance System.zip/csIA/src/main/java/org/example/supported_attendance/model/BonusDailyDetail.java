package org.example.supported_attendance.model;

public record BonusDailyDetail(String workDate, long completedMinutes, boolean validDay) {}
