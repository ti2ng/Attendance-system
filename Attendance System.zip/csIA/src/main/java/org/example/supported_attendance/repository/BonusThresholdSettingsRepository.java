package org.example.supported_attendance.repository;

import java.math.BigDecimal;

import org.example.supported_attendance.model.BonusThresholdSettings;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class BonusThresholdSettingsRepository {
    private final JdbcTemplate jdbcTemplate;

    public BonusThresholdSettingsRepository(JdbcTemplate jdbcTemplate) { this.jdbcTemplate = jdbcTemplate; }

    public BonusThresholdSettings get() {
        return jdbcTemplate.queryForObject("SELECT * FROM bonus_threshold_settings WHERE settings_id=1",
                (rs, row) -> new BonusThresholdSettings(
                        rs.getInt("daily_work_minutes_threshold"),
                        rs.getInt("monthly_valid_days_threshold"),
                        rs.getBigDecimal("daily_bonus_threshold"),
                        rs.getBigDecimal("monthly_bonus_cap_threshold"),
                        rs.getString("updated_at")));
    }

    public void update(int dailyMinutes, int monthlyDays, BigDecimal dailyBonus, BigDecimal monthlyCap) {
        jdbcTemplate.update("UPDATE bonus_threshold_settings SET daily_work_minutes_threshold=?, "
                        + "monthly_valid_days_threshold=?, daily_bonus_threshold=?, "
                        + "monthly_bonus_cap_threshold=?, updated_at=strftime('%Y-%m-%dT%H:%M:%SZ','now') "
                        + "WHERE settings_id=1",
                dailyMinutes, monthlyDays, dailyBonus, monthlyCap);
    }
}
