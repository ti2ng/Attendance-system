package org.example.supported_attendance.model;

public record AttendanceSession(long sessionId, long workerId, String workerNumber,
        String workerName, String tokenValue, String checkInTime, String checkOutTime,
        String status, String updatedAt) {

    public Long durationMinutes() {
        if (checkOutTime == null || checkOutTime.isBlank()) return null;
        try {
            return Math.max(0, (java.time.Instant.parse(checkOutTime).toEpochMilli()
                    - java.time.Instant.parse(checkInTime).toEpochMilli()) / 60000);
        } catch (RuntimeException exception) {
            return null;
        }
    }

    public String checkInDisplay() { return display(checkInTime); }

    public String checkOutDisplay() {
        return checkOutTime == null || checkOutTime.isBlank() ? "-" : display(checkOutTime);
    }

    private static String display(String value) {
        try {
            return java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")
                    .withZone(java.time.ZoneId.of("Asia/Shanghai"))
                    .format(java.time.Instant.parse(value));
        } catch (RuntimeException exception) {
            return value;
        }
    }
}
