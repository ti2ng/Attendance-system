package org.example.supported_attendance.config;

import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.annotation.Order;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

@Component
@Order(0)
public class WorkerSchemaMigration implements ApplicationRunner {

    private final JdbcTemplate jdbcTemplate;

    public WorkerSchemaMigration(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public void run(ApplicationArguments arguments) {
        addColumnIfMissing("id_document_type", "TEXT");
        addColumnIfMissing("id_document_number", "TEXT");
        addColumnIfMissing("contact_phone", "TEXT");
        addColumnIfMissing("updated_at", "TEXT");

        jdbcTemplate.update("UPDATE supported_worker SET id_document_type = 'OTHER' "
                + "WHERE id_document_type IS NULL OR trim(id_document_type) = ''");
        jdbcTemplate.update("UPDATE supported_worker SET id_document_number = 'DEMO-ID-MIGRATED-' || worker_id "
                + "WHERE id_document_number IS NULL OR trim(id_document_number) = ''");
        jdbcTemplate.update("UPDATE supported_worker SET updated_at = created_at "
                + "WHERE updated_at IS NULL OR trim(updated_at) = ''");
        jdbcTemplate.execute("CREATE UNIQUE INDEX IF NOT EXISTS ux_supported_worker_id_document "
                + "ON supported_worker(id_document_number)");
    }

    private void addColumnIfMissing(String column, String definition) {
        Boolean exists = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) > 0 FROM pragma_table_info('supported_worker') WHERE name = ?",
                Boolean.class,
                column);
        if (!Boolean.TRUE.equals(exists)) {
            jdbcTemplate.execute("ALTER TABLE supported_worker ADD COLUMN " + column + " " + definition);
        }
    }
}
