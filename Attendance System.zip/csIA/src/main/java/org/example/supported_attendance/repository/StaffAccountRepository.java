package org.example.supported_attendance.repository;

import java.util.Optional;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class StaffAccountRepository {

    private final JdbcTemplate jdbcTemplate;

    public StaffAccountRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public Optional<StaffAccount> findByUsername(String username) {
        return jdbcTemplate.query(
                        "SELECT staff_id, username, password_hash, active "
                                + "FROM staff_account WHERE username = ?",
                        (resultSet, rowNumber) -> new StaffAccount(
                                resultSet.getLong("staff_id"),
                                resultSet.getString("username"),
                                resultSet.getString("password_hash"),
                                resultSet.getBoolean("active")),
                        username)
                .stream()
                .findFirst();
    }

    public boolean createIfMissing(String username, String passwordHash) {
        int rows = jdbcTemplate.update(
                "INSERT OR IGNORE INTO staff_account (username, password_hash, active) VALUES (?, ?, 1)",
                username,
                passwordHash);
        return rows == 1;
    }

    public record StaffAccount(long staffId, String username, String passwordHash, boolean active) {
    }
}
