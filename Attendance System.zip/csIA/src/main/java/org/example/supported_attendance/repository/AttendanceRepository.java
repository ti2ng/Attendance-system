package org.example.supported_attendance.repository;

import java.util.List;
import java.util.Optional;

import org.example.supported_attendance.model.AttendanceSession;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class AttendanceRepository {
    public record CompletedInterval(long workerId, String checkInTime, String checkOutTime) {}
    private final JdbcTemplate jdbcTemplate;

    public AttendanceRepository(JdbcTemplate jdbcTemplate) { this.jdbcTemplate = jdbcTemplate; }

    public Optional<AttendanceSession> findOpenForWorker(long workerId) {
        return query("SELECT a.*, w.worker_number, w.display_name, t.token_value FROM attendance_session a "
                + "JOIN supported_worker w ON w.worker_id=a.worker_id JOIN identity_token t ON t.token_id=a.token_id "
                + "WHERE a.worker_id=? AND a.status='OPEN'", workerId).stream().findFirst();
    }

    public Optional<AttendanceSession> findLatestForToken(long tokenId) {
        return query("SELECT a.*, w.worker_number, w.display_name, t.token_value FROM attendance_session a "
                + "JOIN supported_worker w ON w.worker_id=a.worker_id JOIN identity_token t ON t.token_id=a.token_id "
                + "WHERE a.token_id=? ORDER BY a.updated_at DESC LIMIT 1", tokenId).stream().findFirst();
    }

    /** Only past records can represent a previous physical scan. */
    public Optional<AttendanceSession> findLatestForTokenAtOrBefore(long tokenId, String time) {
        return query("SELECT a.*, w.worker_number, w.display_name, t.token_value FROM attendance_session a "
                + "JOIN supported_worker w ON w.worker_id=a.worker_id JOIN identity_token t ON t.token_id=a.token_id "
                + "WHERE a.token_id=? AND a.updated_at<=? ORDER BY a.updated_at DESC LIMIT 1", tokenId, time)
                .stream().findFirst();
    }

    public List<AttendanceSession> findAll() {
        return query("SELECT a.*, w.worker_number, w.display_name, t.token_value FROM attendance_session a "
                + "JOIN supported_worker w ON w.worker_id=a.worker_id JOIN identity_token t ON t.token_id=a.token_id "
                + "ORDER BY a.check_in_time DESC");
    }

    public List<CompletedInterval> findCompletedBetween(String start, String end) {
        return jdbcTemplate.query("SELECT worker_id, check_in_time, check_out_time FROM attendance_session "
                        + "WHERE status='COMPLETED' AND check_in_time>=? AND check_in_time<? ORDER BY check_in_time",
                (rs, row) -> new CompletedInterval(rs.getLong("worker_id"), rs.getString("check_in_time"),
                        rs.getString("check_out_time")), start, end);
    }

    public AttendanceSession checkIn(long workerId, long tokenId, String now) {
        jdbcTemplate.update("INSERT INTO attendance_session(worker_id, token_id, check_in_time, updated_at) VALUES (?, ?, ?, ?)",
                workerId, tokenId, now, now);
        return findOpenForWorker(workerId).orElseThrow();
    }

    public AttendanceSession checkOut(long sessionId, String now) {
        jdbcTemplate.update("UPDATE attendance_session SET check_out_time=?, status='COMPLETED', updated_at=? WHERE session_id=?",
                now, now, sessionId);
        return query("SELECT a.*, w.worker_number, w.display_name, t.token_value FROM attendance_session a "
                + "JOIN supported_worker w ON w.worker_id=a.worker_id JOIN identity_token t ON t.token_id=a.token_id "
                + "WHERE a.session_id=?", sessionId).stream().findFirst().orElseThrow();
    }

    private List<AttendanceSession> query(String sql, Object... args) {
        return jdbcTemplate.query(sql, (rs, row) -> new AttendanceSession(rs.getLong("session_id"),
                rs.getLong("worker_id"), rs.getString("worker_number"), rs.getString("display_name"),
                rs.getString("token_value"), rs.getString("check_in_time"), rs.getString("check_out_time"),
                rs.getString("status"), rs.getString("updated_at")), args);
    }
}
