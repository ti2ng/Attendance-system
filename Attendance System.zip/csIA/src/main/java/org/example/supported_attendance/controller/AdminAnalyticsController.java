package org.example.supported_attendance.controller;

import java.time.YearMonth;
import java.time.ZoneId;
import java.math.BigDecimal;

import org.example.supported_attendance.repository.AnalyticsRepository;
import org.example.supported_attendance.repository.BonusThresholdSettingsRepository;
import org.example.supported_attendance.service.MonthlyBonusService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AdminAnalyticsController {
    private static final ZoneId ZONE = ZoneId.of("Asia/Shanghai");
    private final MonthlyBonusService bonusService;
    private final BonusThresholdSettingsRepository thresholdRepository;
    private final AnalyticsRepository analyticsRepository;

    public AdminAnalyticsController(MonthlyBonusService bonusService,
            BonusThresholdSettingsRepository thresholdRepository, AnalyticsRepository analyticsRepository) {
        this.bonusService = bonusService;
        this.thresholdRepository = thresholdRepository;
        this.analyticsRepository = analyticsRepository;
    }

    @GetMapping("/admin/analytics")
    public String analytics(@RequestParam(required = false) String month, Model model) {
        String defaultMonth = YearMonth.now(ZONE).minusMonths(1).toString();
        String selected = bonusService.normalizeMonth(month == null || month.isBlank() ? defaultMonth : month);
        bonusService.calculate(selected);
        var threshold = thresholdRepository.get();
        YearMonth yearMonth = YearMonth.parse(selected);
        String start = yearMonth.atDay(1).atStartOfDay(ZONE).toInstant().toString();
        String end = yearMonth.plusMonths(1).atDay(1).atStartOfDay(ZONE).toInstant().toString();
        var results = bonusService.findByMonth(selected);
        var daily = analyticsRepository.dailyAttendance(start, end, threshold.dailyWorkMinutesThreshold());
        int qualifiedCount = (int) results.stream().filter(result -> result.qualified()).count();
        int cappedCount = (int) results.stream()
                .filter(result -> result.finalBonus().signum() > 0
                        && result.finalBonus().compareTo(result.monthlyBonusCapThreshold()) >= 0)
                .count();
        BigDecimal totalBonus = results.stream().map(result -> result.finalBonus())
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        model.addAttribute("month", selected);
        model.addAttribute("results", results);
        model.addAttribute("dailyAttendance", daily);
        model.addAttribute("threshold", threshold);
        model.addAttribute("qualifiedCount", qualifiedCount);
        model.addAttribute("notQualifiedCount", results.size() - qualifiedCount);
        model.addAttribute("cappedCount", cappedCount);
        model.addAttribute("totalBonus", totalBonus);
        return "admin/analytics";
    }
}
