package org.example.supported_attendance.service;

import java.util.List;

import org.example.supported_attendance.model.Worker;
import org.example.supported_attendance.repository.WorkerRepository;
import org.example.supported_attendance.web.WorkerForm;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class WorkerService {

    private final WorkerRepository workerRepository;
    private final I18nService i18n;

    public WorkerService(WorkerRepository workerRepository, I18nService i18n) {
        this.workerRepository = workerRepository;
        this.i18n = i18n;
    }

    public List<Worker> search(String query) {
        return workerRepository.search(query);
    }

    public Worker get(long workerId) {
        return workerRepository.findById(workerId)
                .orElseThrow(() -> new WorkerNotFoundException(workerId));
    }

    public WorkerForm toForm(long workerId) {
        Worker worker = get(workerId);
        WorkerForm form = new WorkerForm();
        form.setWorkerNumber(worker.workerNumber());
        form.setFullName(worker.fullName());
        form.setIdDocumentType(worker.idDocumentType());
        form.setIdDocumentNumber(worker.idDocumentNumber());
        form.setContactPhone(worker.contactPhone());
        return form;
    }

    @Transactional
    public long create(WorkerForm form) {
        normalizeAndCheckUnique(form, null);
        try {
            return workerRepository.create(
                    form.getWorkerNumber(), form.getFullName(), form.getIdDocumentType(),
                    form.getIdDocumentNumber(), blankToNull(form.getContactPhone()));
        } catch (DataIntegrityViolationException exception) {
            throw duplicateFromCurrentData(form, null, exception);
        }
    }

    @Transactional
    public void update(long workerId, WorkerForm form) {
        get(workerId);
        normalizeAndCheckUnique(form, workerId);
        try {
            workerRepository.update(
                    workerId, form.getWorkerNumber(), form.getFullName(), form.getIdDocumentType(),
                    form.getIdDocumentNumber(), blankToNull(form.getContactPhone()));
        } catch (DataIntegrityViolationException exception) {
            throw duplicateFromCurrentData(form, workerId, exception);
        }
    }

    @Transactional
    public void setActive(long workerId, boolean active) {
        if (workerRepository.setActive(workerId, active) == 0) {
            throw new WorkerNotFoundException(workerId);
        }
    }

    private void normalizeAndCheckUnique(WorkerForm form, Long excludedWorkerId) {
        form.trimValues();
        if (workerRepository.existsByWorkerNumber(form.getWorkerNumber(), excludedWorkerId)) {
            throw new DuplicateWorkerFieldException("workerNumber", i18n.text("message.workerNumber.duplicate"));
        }
        if (workerRepository.existsByIdDocumentNumber(form.getIdDocumentNumber(), excludedWorkerId)) {
            throw new DuplicateWorkerFieldException("idDocumentNumber", i18n.text("message.documentNumber.duplicate"));
        }
    }

    private DuplicateWorkerFieldException duplicateFromCurrentData(
            WorkerForm form, Long excludedWorkerId, DataIntegrityViolationException cause) {
        if (workerRepository.existsByWorkerNumber(form.getWorkerNumber(), excludedWorkerId)) {
            return new DuplicateWorkerFieldException("workerNumber", i18n.text("message.workerNumber.duplicate"));
        }
        if (workerRepository.existsByIdDocumentNumber(form.getIdDocumentNumber(), excludedWorkerId)) {
            return new DuplicateWorkerFieldException("idDocumentNumber", i18n.text("message.documentNumber.duplicate"));
        }
        throw cause;
    }

    private static String blankToNull(String value) {
        return value == null || value.isBlank() ? null : value;
    }
}
