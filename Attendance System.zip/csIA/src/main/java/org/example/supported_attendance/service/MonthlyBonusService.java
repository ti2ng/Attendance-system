package org.example.supported_attendance.service;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.example.supported_attendance.model.BonusDailyDetail;
import org.example.supported_attendance.model.MonthlyBonusResult;
import org.example.supported_attendance.repository.AttendanceRepository;
import org.example.supported_attendance.repository.BonusThresholdSettingsRepository;
import org.example.supported_attendance.repository.MonthlyBonusRepository;
import org.example.supported_attendance.repository.WorkerRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class MonthlyBonusService {
    private static final ZoneId BUSINESS_ZONE = ZoneId.of("Asia/Shanghai");

    private final AttendanceRepository attendanceRepository;
    private final BonusThresholdSettingsRepository thresholdRepository;
    private final MonthlyBonusRepository bonusRepository;
    private final WorkerRepository workerRepository;
    private final I18nService i18n;

    public MonthlyBonusService(AttendanceRepository attendanceRepository,
            BonusThresholdSettingsRepository thresholdRepository, MonthlyBonusRepository bonusRepository,
            WorkerRepository workerRepository, I18nService i18n) {
        this.attendanceRepository = attendanceRepository;
        this.thresholdRepository = thresholdRepository;
        this.bonusRepository = bonusRepository;
        this.workerRepository = workerRepository;
        this.i18n = i18n;
    }

    public List<MonthlyBonusResult> findByMonth(String month) {
        return bonusRepository.findByMonth(normalizeMonth(month));
    }

    public List<BonusDailyDetail> findDetails(long resultId) { return bonusRepository.findDetails(resultId); }

    @Transactional
    public void calculate(String rawMonth) {
        String month = normalizeMonth(rawMonth);
        YearMonth yearMonth = YearMonth.parse(month);
        Instant start = yearMonth.atDay(1).atStartOfDay(BUSINESS_ZONE).toInstant();
        Instant end = yearMonth.plusMonths(1).atDay(1).atStartOfDay(BUSINESS_ZONE).toInstant();
        var thresholds = thresholdRepository.get();

        Map<Long, Map<LocalDate, Long>> minutesByWorkerAndDay = new HashMap<>();
        for (var interval : attendanceRepository.findCompletedBetween(start.toString(), end.toString())) {
            Instant checkIn = Instant.parse(interval.checkInTime());
            Instant checkOut = Instant.parse(interval.checkOutTime());
            long minutes = Math.max(0, Duration.between(checkIn, checkOut).toMinutes());
            LocalDate workDate = checkIn.atZone(BUSINESS_ZONE).toLocalDate();
            minutesByWorkerAndDay.computeIfAbsent(interval.workerId(), ignored -> new HashMap<>())
                    .merge(workDate, minutes, Long::sum);
        }

        String calculatedAt = Instant.now().toString();
        for (var worker : workerRepository.search("")) {
            Map<LocalDate, Long> dailyMinutes = minutesByWorkerAndDay.getOrDefault(worker.workerId(), Map.of());
            List<BonusDailyDetail> details = dailyMinutes.entrySet().stream()
                    .sorted(Map.Entry.comparingByKey())
                    .map(entry -> new BonusDailyDetail(entry.getKey().toString(), entry.getValue(),
                            entry.getValue() >= thresholds.dailyWorkMinutesThreshold()))
                    .toList();
            long totalMinutes = details.stream().mapToLong(BonusDailyDetail::completedMinutes).sum();
            int validDays = (int) details.stream().filter(BonusDailyDetail::validDay).count();
            boolean qualified = validDays >= thresholds.monthlyValidDaysThreshold();
            BigDecimal rawBonus = thresholds.dailyBonusThreshold().multiply(BigDecimal.valueOf(validDays));
            BigDecimal finalBonus = qualified ? rawBonus.min(thresholds.monthlyBonusCapThreshold()) : BigDecimal.ZERO;

            long resultId = bonusRepository.replace(worker.workerId(), month,
                    thresholds.dailyWorkMinutesThreshold(), thresholds.monthlyValidDaysThreshold(),
                    thresholds.dailyBonusThreshold(), thresholds.monthlyBonusCapThreshold(), totalMinutes,
                    validDays, rawBonus, finalBonus, qualified ? "QUALIFIED" : "NOT_QUALIFIED", calculatedAt);
            details.forEach(detail -> bonusRepository.addDetail(resultId, detail));
        }
    }

    public String normalizeMonth(String rawMonth) {
        String value = rawMonth == null || rawMonth.isBlank() ? YearMonth.now(BUSINESS_ZONE).toString() : rawMonth.trim();
        try {
            return YearMonth.parse(value).toString();
        } catch (RuntimeException exception) {
            throw new IllegalArgumentException(i18n.text("message.month.invalid"));
        }
    }
}
