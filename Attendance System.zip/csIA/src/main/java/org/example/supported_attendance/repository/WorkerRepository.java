package org.example.supported_attendance.repository;

import java.util.List;
import java.util.Optional;

import org.example.supported_attendance.model.Worker;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

@Repository
public class WorkerRepository {

    private static final RowMapper<Worker> WORKER_ROW_MAPPER = (resultSet, rowNumber) -> new Worker(
            resultSet.getLong("worker_id"),
            resultSet.getString("worker_number"),
            resultSet.getString("display_name"),
            resultSet.getString("id_document_type"),
            resultSet.getString("id_document_number"),
            resultSet.getString("contact_phone"),
            resultSet.getBoolean("active"),
            resultSet.getString("created_at"),
            resultSet.getString("updated_at"));

    private final JdbcTemplate jdbcTemplate;

    public WorkerRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public int countAll() {
        Integer count = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM supported_worker",
                Integer.class);
        return count == null ? 0 : count;
    }

    public List<Worker> search(String query) {
        String normalized = query == null ? "" : query.trim();
        if (normalized.isEmpty()) {
            return jdbcTemplate.query(
                    "SELECT * FROM supported_worker ORDER BY active DESC, worker_number",
                    WORKER_ROW_MAPPER);
        }
        String pattern = "%" + normalized + "%";
        return jdbcTemplate.query(
                "SELECT * FROM supported_worker "
                        + "WHERE worker_number LIKE ? OR display_name LIKE ? "
                        + "OR id_document_number LIKE ? OR contact_phone LIKE ? "
                        + "ORDER BY active DESC, worker_number",
                WORKER_ROW_MAPPER,
                pattern, pattern, pattern, pattern);
    }

    public Optional<Worker> findById(long workerId) {
        return jdbcTemplate.query(
                        "SELECT * FROM supported_worker WHERE worker_id = ?",
                        WORKER_ROW_MAPPER,
                        workerId)
                .stream()
                .findFirst();
    }

    public boolean existsByWorkerNumber(String workerNumber, Long excludedWorkerId) {
        return exists("worker_number", workerNumber, excludedWorkerId);
    }

    public boolean existsByIdDocumentNumber(String idDocumentNumber, Long excludedWorkerId) {
        return exists("id_document_number", idDocumentNumber, excludedWorkerId);
    }

    public long create(String workerNumber, String fullName, String documentType,
            String documentNumber, String contactPhone) {
        jdbcTemplate.update(
                "INSERT INTO supported_worker "
                        + "(worker_number, display_name, id_document_type, id_document_number, contact_phone) "
                        + "VALUES (?, ?, ?, ?, ?)",
                workerNumber, fullName, documentType, documentNumber, contactPhone);
        Long id = jdbcTemplate.queryForObject("SELECT last_insert_rowid()", Long.class);
        return id == null ? 0 : id;
    }

    public int update(long workerId, String workerNumber, String fullName, String documentType,
            String documentNumber, String contactPhone) {
        return jdbcTemplate.update(
                "UPDATE supported_worker SET worker_number = ?, display_name = ?, "
                        + "id_document_type = ?, id_document_number = ?, contact_phone = ?, "
                        + "updated_at = strftime('%Y-%m-%dT%H:%M:%SZ', 'now') WHERE worker_id = ?",
                workerNumber, fullName, documentType, documentNumber, contactPhone, workerId);
    }

    public int setActive(long workerId, boolean active) {
        return jdbcTemplate.update(
                "UPDATE supported_worker SET active = ?, "
                        + "updated_at = strftime('%Y-%m-%dT%H:%M:%SZ', 'now') WHERE worker_id = ?",
                active ? 1 : 0,
                workerId);
    }

    private boolean exists(String column, String value, Long excludedWorkerId) {
        String sql = "SELECT COUNT(*) FROM supported_worker WHERE " + column + " = ?";
        Object[] arguments = {value};
        if (excludedWorkerId != null) {
            sql += " AND worker_id <> ?";
            arguments = new Object[] {value, excludedWorkerId};
        }
        Integer count = jdbcTemplate.queryForObject(sql, Integer.class, arguments);
        return count != null && count > 0;
    }
}
