package org.example.supported_attendance;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SupportedAttendanceApplication {

	public static void main(String[] args) {
		createDataDirectory();
		SpringApplication.run(SupportedAttendanceApplication.class, args);
	}

	private static void createDataDirectory() {
		try {
			Files.createDirectories(Path.of("data"));
		} catch (IOException exception) {
			throw new IllegalStateException("Unable to create the SQLite data directory", exception);
		}
	}

}
