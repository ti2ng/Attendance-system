package org.example.supported_attendance.service;

import java.util.List;

import org.example.supported_attendance.model.IdentityToken;
import org.example.supported_attendance.model.Worker;
import org.example.supported_attendance.repository.IdentityTokenRepository;
import org.example.supported_attendance.repository.WorkerRepository;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class IdentityTokenService {
    private final IdentityTokenRepository tokenRepository;
    private final WorkerRepository workerRepository;
    private final I18nService i18n;

    public IdentityTokenService(IdentityTokenRepository tokenRepository, WorkerRepository workerRepository,
            I18nService i18n) {
        this.tokenRepository = tokenRepository;
        this.workerRepository = workerRepository;
        this.i18n = i18n;
    }

    public List<IdentityToken> findForWorker(long workerId) { return tokenRepository.findForWorker(workerId); }
    public List<IdentityToken> findAll() { return tokenRepository.findAll(); }

    @Transactional
    public void bind(long workerId, String rawValue) {
        Worker worker = workerRepository.findById(workerId).orElseThrow(() -> new WorkerNotFoundException(workerId));
        if (!worker.active()) throw new IllegalArgumentException(i18n.text("message.token.inactive"));
        String value = rawValue == null ? "" : rawValue.trim().toUpperCase();
        if (!value.matches("[A-Z0-9-]{4,50}")) throw new IllegalArgumentException(i18n.text("message.token.format"));
        try {
            tokenRepository.create(workerId, value);
        } catch (DataIntegrityViolationException exception) {
            throw new IllegalArgumentException(i18n.text("message.token.duplicate"));
        }
    }

    public void revoke(long workerId, long tokenId) {
        boolean belongs = tokenRepository.findForWorker(workerId).stream().anyMatch(token -> token.tokenId() == tokenId);
        if (!belongs || tokenRepository.revoke(tokenId) == 0) throw new IllegalArgumentException(i18n.text("message.token.notFound"));
    }
}
